//This is unpublished source code. Michah Lerner 2006

package util.coll;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.Map;

/**
 * This provides a flexible generic sort for comparables, as well as collections, maps and Pairs.
 * It takes vararg input, which may include collections, comparables and non-comparables.
 * Comparisons use the natural iteration order of the underlying collections.  This is a convenience
 * function but specific cases may require special handling to be certifiable, in order to eliminate
 * possible dependence on the iterator order.
 */
public class Sortable implements Comparable<Sortable>,
	Comparator<Object> {
	Integer len;
	public Object[] o;
	public Sortable(final Object... o) {
		this.len=o.length;
		this.o = o;
	}

	public String asString() {
		final StringBuffer sb = new StringBuffer();
		for(final Object o1 : this.o) sb.append(o1.toString()+", ");
		sb.delete(sb.length()-2, sb.length()-1);
		return sb.toString();
	}

	/**
	 * Sort collection of objects into an array of sorted objects
	 * @param c collection of objects to sort by placing them into an array and sorting the array
	 * @return The sorted array of objects.
	 */
	Object[] sort(final Collection<?> c) {
		final Object [] o1 = new Object[c.size()];
		final Iterator<?> it = c.iterator();
		for(int pos=0;pos<o1.length;pos++)o1[pos]=it.next();
		Arrays.sort(o1);
		return o1;
	}

	/**
	 * Sort map of objects into an array of sorted objects
	 * @param m collection of objects to sort by placing them into an array and sorting the array
	 * @return The sorted array of objects.
	 */
	@SuppressWarnings("unchecked")
	public
	Sortable[] sort(final Map m) {
		final Sortable[] o1 = new Sortable[m.size()];
		final Iterator<Map.Entry> it = m.entrySet().iterator();
		for(int pos=0;pos<o1.length;pos++) {
			final Map.Entry n = it.next();
			o1[pos]=new Sortable(n.getKey(),n.getValue());
		}
		Arrays.sort(o1);
		return o1;
	}

	/**
	 * Sort map of objects into an array of sorted objects, providing alternate
	 * sort order if desired. Currently uses the same sorting method as the sort
	 * method.
	 *
	 * @param m collection of objects to sort by placing them into an array and sorting the array
	 * @return The sorted array of objects.
	 */
	@SuppressWarnings("unchecked")
	public
	Sortable[] sort2(final Map m) {
		final Sortable[] o1 = new Sortable[m.size()];
		final Iterator<Map.Entry> it = m.entrySet().iterator();
		for(int pos=0;pos<o1.length;pos++) {
			final Map.Entry n = it.next();
			o1[pos]=new Sortable(n.getValue(),n.getKey());
		}
		Arrays.sort(o1);
		return o1;
	}

	/**
	 * CompareTo function over sortables.  It loops over a pair of Sortables, returning the comparison for the first non-zero comparison.
	 */
	@SuppressWarnings("unchecked")
	public int compareTo(final Sortable o1) {
		int diff = 0;
		for (int i = 0; i < Math.min(this.len, o1.len); i++) {
			if (this.o[i] instanceof Comparable && o1.o[i] instanceof Comparable) {
				diff = ((Comparable<Object>) this.o[i]).compareTo(o1.o[i]);
				if (diff != 0) return diff;
			} else {
				if(this.o[i] instanceof Collection && o1.o[i] instanceof Collection) {
					diff=compare((Collection<Collection>)this.o[i], (Collection<Collection>)o1.o[i]);
					if(diff != 0) return diff;
				}
			}
		}
		return this.o.length - o1.o.length;
	}

	@Override
	public int hashCode() {
		int hashcode=super.hashCode();
		if(len!=0)hashcode+=len.hashCode();
		if(o!=null)for(final Object ob : o)hashcode+=ob.hashCode();
		return hashcode;
	}

	// Since we give a compareTo we should also follow best-practice and define an equals.
	public boolean equals(final Sortable o1) {
		return this.compareTo(o1)==0;
	}

	@Override
	public boolean equals(final Object o1) {
		if(!this.getClass().equals(o1.getClass()))return false;
		return this.equals((Sortable)o1);
	}

	@SuppressWarnings("unchecked")
	public int compare(final Collection<Collection> o1, final Collection<Collection> o2) {
		final Iterator<Collection>i1=o1.iterator();
		final Iterator<Collection>i2=o2.iterator();
		int diff;
		while(i1.hasNext()&&i2.hasNext()) {
			final Object ob1=i1.next();
			final Object ob2=i2.next();
			if(ob1 instanceof Comparable && ob2 instanceof Comparable) {
				diff = ((Comparable<Object>) ob1).compareTo(ob2);
				if (diff != 0) return diff;
			}
		}
		if(i1.hasNext())return 1;
		if(i2.hasNext())return -1;
		return 0;
	}

	@SuppressWarnings("unchecked")
	public int compare(final Comparable<Comparable> o1, final Comparable o2) {
		return o1.compareTo(o2);
	}

	public int compare(final Object o1, final Object o2) {
		final int h1=o1.hashCode();
		final int h2=o2.hashCode();
		if(h1<h2)return -1;
		if(h1>h2)return 1;
		return 0;
	}

	public int compare(final Pair<? extends Comparable, ? extends Comparable> o1,
			final Pair<? extends Comparable, ? extends Comparable> o2) {
		int cmp = o1.s().compareTo(o2.s());
		if(cmp==0)cmp=o1.t().compareTo(o2.t());
		return cmp;
	}

}

