// This is unpublished source code. Michah Lerner 2006

package interfaces;

import java.util.Collection;
import java.util.List;

/**
 * The PredicateEvaluator provides an interface for passing a functional test into a search routine. The test must
 * implement a setter (called <code>newInput</code>) to be called with the new input to find keywords for. The test
 * must also implement a predicate <code>foundP</code> which does the work of figuring out whether a set of keywords
 * should be allowed as a keyword match. The <code>foundP</code> should also return the kind of keyword match that the
 * words provide, as defined by the <code>enum PhraseType</enum>.
 * @author Michah.Lerner
 *
 * @param <S> the class the predicate operates on.
 */
public interface PredicateEvaluator<S> {

	/**
	 * Predicate form for search control. The foundP routine should evaluate whether the <code>arg</code> is a good
	 * representative of the current <code>wordSet</code> (the wordSet was set by the most recent call to
	 * <code>newInput</newInput>). the evaluation can be arbitrary
	 * @param arg the words to consider as a cluster that represents the wordSet
	 * @return The phraseType that would best allow these keywords to serve as a
	 * representative for the wordSet.
	 */

	float getProbAsSet(final Collection<String> arg);

	float getProbAsSequence(final Collection<String> arg);

	float getProbAsPhrase(final Collection<String> arg);

	MatchInfoIF getProbPhraseType(Collection<S> arg);

	/**
	 * Sets the current instance of words that we are tying to find a keymatch for.
	 * 
	 * @param wordSet
	 */
	void newInput(final Collection<S> words);

	List<S> getInput();

}
