//This is unpublished source code. Michah Lerner 2006

package interfaces;

/**
 * Iterable ID interface
 * @author Michah.Lerner
 *
 */

public interface IID {
	int next();
}