// This is unpublished source code. Michah Lerner 2006

package interfaces;

import java.util.Iterator;

import docStore.DocFactory.Doc;

/**
 * Interface for iterating over documents
 * 
 * @author Michah.Lerner
 * 
 */
public interface DocIterator {
	Iterator<String> docIterator = null;

	public Doc next();

	public boolean hasNext();
}
