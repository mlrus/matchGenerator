// This is unpublished source code. Michah Lerner 2006

package interfaces;

import java.util.Collection;
import java.util.ListIterator;

import docStore.DocumentsContentIterator;
import docStore.DocFactory.Doc;

/**
 * Interface for iteration of "documents" for example as stored in a DocumentStore or a file of string.
 * 
 * @author Michah.Lerner
 * 
 * @param <S>
 *            The type of item to iterator over
 * @see DocumentsContentIterator (iterator over DocumentStore)
 * @see MultilineFileIterator (iterator over lines of a file)
 * @see MultilineDocFileIterator (iterator over lines of a file which update partial contents of a DocumentStore)
 */
public interface ContentIteratorIF<S> {
	// Iterator<String> contentIterator=null;
	ListIterator<String> contentIterator = null;

	public boolean hasNext();

	public Doc next();

	public Doc updateCurrent(Collection<String> newContents);

	Doc add(Doc record);

	public Collection<String> previous();

	public boolean hasPrevious();

}