package match;

public class Fchar extends Cseq {
	final char[] ch;
	int from, to;

	public Fchar(final char[] ch) {
		this(ch, 0, ch.length);
	}

	public Fchar(final String s) {
		this(s.toCharArray(), 0, s.length());
	}

	Fchar(final char[] ch, final int from, final int to) {
		this.ch = ch;
		this.from = from;
		this.to = to - 1;
	}

	@Override
	public char charAt(final int index) {
		return ch[from + index];
	}

	@Override
	public int length() {
		return to - from + 1;
	}

	@Override
	public Fchar subSequence(final int nfrom, final int nto) {
		return new Fchar(ch, this.from + nfrom, this.from + nto);
	}

	@Override
	public String toString() {
		// return to - from + 1 + "::" + String.valueOf(ch, from, (to - from) + 1);
		return String.valueOf(ch, from, (to - from) + 1);
	}
}