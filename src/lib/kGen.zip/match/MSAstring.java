package match;

import java.util.Iterator;

import docStore.ContentIterator;

public class MSAstring extends MSAfunctions<StringEntry> {

	public MSAstring(final String filename) {
		final Iterator<StringEntry> contentIterator = StringEntry.getIterator(ContentIterator.get(filename));
		buildSA(contentIterator);
	}

	public MSAstring() {
	}

}
