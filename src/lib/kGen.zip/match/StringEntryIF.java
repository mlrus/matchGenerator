package match;

import interfaces.EntryData;

/***********************************************************************************************************************
 * Class StringEntry is an EntryData wrapper for a string. It is for test/transition only.
 * 
 * @author mlrus
 * 
 */

public interface StringEntryIF<S extends EntryData<S>> {

}
