package bayesMatchGenerator;

import generators.ChooseCombIF;
import interfaces.Chooser;
import interfaces.FilterComb;
import interfaces.PredicateEvaluator;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.ListIterator;
import java.util.Set;

import match.Fchar;
import util.Constants;
import util.coll.PairNC;
import docStore.DocumentStore;

public class CFilter<S> implements FilterComb<String> {
	boolean debug = false;
	boolean subsume = false;
	final static float subsumptionThresholdSet = (float) (1f - 1e-6);
	final static float subsumptionThresholdPhrase = (float) (1e-6);
	final static float minProbAsSequence = (float) 1e-6;
	final static float minProbAsSet = Math.min(subsumptionThresholdSet, (float) 1e-6);
	final static float goldenRatio = 15f;
	final static float erosionRate = 0.95f;
	final static int maxSizeToPermute = 4;
	private final Chooser<String> chooser;
	private final PredicateEvaluator<String> evaluator;
	private final List<Set<String>> minPoints;

	public CFilter(final PredicateEvaluator<String> evaluator) {
		this.chooser = new ChooseCombIF<String>();
		this.evaluator = evaluator;
		minPoints = new ArrayList<Set<String>>();
	}

	public List<PairNC<MatchInfo, Collection<String>>> collectResults(final Collection<String> content) {
		final LinkedHashSet<String> contentCopy = new LinkedHashSet<String>(content);
		evaluator.newInput(content);
		final List<List<String>> candidates = chooser.chooseCombIF((List<String>) content);
		final List<PairNC<MatchInfo, Collection<String>>> KWResults = expandAndTestCandidates(contentCopy, candidates);

		if (content.size() != contentCopy.size()) {
			if (contentCopy.size() > 0) {
				System.out.println("Reduced from " + content.size() + " to " + contentCopy.size() + ": " + content + " :: "
						+ contentCopy);
			}
		}

		// final float probAsPhrase = evaluator.getProbAsPhrase(currentSet);
		final List<String> availableWords = new ArrayList<String>(contentCopy);
		final List<PairNC<MatchInfo, Collection<String>>> PHResults = expandAndTestPhrases(availableWords);// evaluator.getInput());
		if (PHResults.size() > 0) {
			final List<PairNC<MatchInfo, Collection<String>>> kept = new ArrayList<PairNC<MatchInfo, Collection<String>>>();
			for (final PairNC<MatchInfo, Collection<String>> pnc : KWResults) {
				for (final PairNC<MatchInfo, Collection<String>> pnc2 : PHResults) {
					if (pnc2.t().containsAll(pnc.t())) {
						// System.out.println("SkipA: " + pnc);
						break;
					}
					if (pnc.t().containsAll(pnc2.t())) {
						// System.out.println("SkipB: " + pnc);
						break;
					}

					// System.out.println("Keep: " + pnc);
					kept.add(pnc);
				}
			}
			PHResults.addAll(kept);
			// for (final PairNC<MatchInfo, Collection<String>> pnc : PHResults) {
			// System.out.println(pnc.s().prob + "::" + pnc.s().phraseType + "::" + pnc.t());
			// }
		}
		return PHResults;
	}

	/**
	 * Predicate to say whether an item subsumes other items.
	 * 
	 * @param res
	 * @return true if res subsumes.
	 */

	boolean subsumed(final Set<String> res) {
		if (minPoints == null) {
			return false;
		}
		for (final Set<String> ans : minPoints) {
			if (res.containsAll(ans)) {
				if (debug) {
					System.out.println("subsume: " + res + " from " + minPoints);
				}
				return true;
			}
		}
		return false;
	}

	/**
	 * Test each combination using the given PredicateEvaluator, keeping answers according to logic defined and
	 * implemented in the processAnswer routine, and eliminating candidates that contain a "Set" answer since "set" has
	 * the highest threshold. Subsume the candidate set by eliminating supersets of items that are accepted as sets with
	 * very high probability.
	 * 
	 * @param initParams
	 *            A vector of S (typically String) to evaluate
	 * @param tester
	 *            A PredicateEvaluator to tell if a subset is a sufficient representation of a set
	 * @return A list containing the kind of match (set, sequence, exact) and the text of the match
	 */

	@SuppressWarnings("unchecked")
	public List<PairNC<MatchInfo, Collection<String>>> expandAndTestCandidates(final LinkedHashSet<String> contentCopy,
			final List<List<String>> candidates) {
		final List<PairNC<MatchInfo, Collection<String>>> results = new ArrayList<PairNC<MatchInfo, Collection<String>>>();
		float probUsed = 0f;
		// final float probIgnored = 0f;
		int cntUsed = 1;

		for (int pos = 0; pos < candidates.size(); pos++) {
			final List<String> currentSet = candidates.get(pos);
			final float probAsSet = evaluator.getProbAsSet(currentSet);
			final float limit = (float) (goldenRatio * Math.pow(erosionRate, cntUsed));

			if (probAsSet > minProbAsSet) {
				probUsed += probAsSet;
				final float ratio = (probUsed / cntUsed / probAsSet);
				final boolean useThis = ratio <= limit;
				if (useThis) {
					cntUsed++;
					results.add(new PairNC<MatchInfo, Collection<String>>(new MatchInfo(PhraseType.Set, probAsSet), currentSet));
					if (probAsSet > subsumptionThresholdSet) {
						subsumeSet(candidates, currentSet, pos + 1);
						for (final String s : currentSet) {
							contentCopy.remove(s);
						}
					}
				}
				if (debug) {
					System.err
							.printf(
									"            %s probAsSet::emit  prob= %5.3f  avg= %5.3f  ratio= %7.3f  used= %6d  evaled= %6d  avail= %6d  totalProb= %7.3f limit= %5.3f emit= %s\n",
									useThis
											? "T"
											: "F", probAsSet, (probUsed / cntUsed), (probUsed / cntUsed / probAsSet), cntUsed, pos,
									candidates.size(), probUsed, limit, currentSet.toString());
				}

			}
		}
		return results;
	}

	int minPhraseCandidateLen = 2;

	class probInfo implements Comparable<probInfo> {
		float prob;
		int len;
		Fchar text;

		probInfo(final float prob, final int len, final Fchar text) {
			this.prob = prob;
			this.len = len;
			this.text = text;
		}

		@Override
		public String toString() {
			return String.format("%05.3f %04d %s", prob, len, text);
		}

		public int compareTo(final probInfo o) {
			int cmp;
			cmp = this.len < o.len
					? -1
					: this.len > o.len
							? 1
							: 0;
			if (cmp == 0) {
				cmp = this.prob < o.prob
						? 1
						: this.prob > o.prob
								? -1
								: 0;
			}

			if (cmp == 0) {
				cmp = this.text.compareTo(o.text);
			}
			return cmp;
		}
	}

	public List<PairNC<MatchInfo, Collection<String>>> expandAndTestPhrases(final List<String> text) {
		final List<PairNC<MatchInfo, Collection<String>>> results = new ArrayList<PairNC<MatchInfo, Collection<String>>>();
		if (text.size() >= minPhraseCandidateLen) {
			final int[] spos = new int[text.size() + 1];
			final char[] ftext = mkSdelim(text, spos);
			final Fchar fChar = new Fchar(ftext);
			final List<probInfo> info = new ArrayList<probInfo>();
			for (int s = 0; s < spos.length - minPhraseCandidateLen; s++) {
				for (int e = s + minPhraseCandidateLen; e < spos.length; e++) {
					final Fchar delimitedWords = fChar.subSequence(spos[s] - 1, spos[e]);
					final BitSet bs = DocumentStore.msa.BSgetEntity(delimitedWords);
					final int card = bs.cardinality();
					if (card > 1) {
						final float prob = 1f / card;
						info.add(new probInfo(prob, (e - s), delimitedWords));
					}
				}
			}
			if (info.size() > 0) {
				Collections.sort(info);
				final Float minProb = info.get(0).prob;
				final Integer minLen = info.get(0).len;
				for (final probInfo s : info) {
					if (minProb.equals(s.prob) && minLen.equals(s.len)) {
						results.add(new PairNC<MatchInfo, Collection<String>>(new MatchInfo(PhraseType.Phrase, s.prob),
								new ArrayList<String>(Arrays.asList(s.text.toString().trim().split(" +")))));
					}
				}
			}
		}
		return results;
	}

	char[] mkSdelim(final List<String> text, final int[] spos) {
		int len = 1;
		if (spos.length != text.size() + 1) {
			System.err.println("Error on invocation: arg2 should be length text.size()+1");
		}
		for (int word = 0; word < text.size(); word++) {
			len += text.get(word).length() + 1;
		}
		final char[] ftext = new char[len];
		int pos = 0;
		ftext[pos++] = ' ';
		for (int word = 0; word < text.size(); word++) {
			spos[word] = pos;
			final String s = text.get(word);
			final int l = s.length();
			s.getChars(0, l, ftext, pos);
			pos += l;
			ftext[pos++] = ' ';
		}
		spos[text.size()] = pos;
		return ftext;
	}

	void showtextBuf(final Fchar fChar, final int[] spos) {
		for (int i = 0; i < spos.length - 1; i++) {
			System.out.print(spos[i] + "..." + (spos[i + 1] - 2) + " [");
			System.out.print(fChar.subSequence(spos[i], spos[i + 1] - 1));
			System.out.println("]");
		}
	}

	boolean subsumablePhraseType(final PhraseType phraseType) {
		return subsume && Constants.subsumables.contains(phraseType);
	}

	void subsumeSet(final List<List<String>> candidates, final List<String> item, final int fromPos) {
		for (int pos2 = fromPos; pos2 < candidates.size(); pos2++) {
			while (pos2 < candidates.size() && candidates.get(pos2).containsAll(item)) {
				candidates.remove(pos2);
			}
		}
	}

	void subsumePhrase(final List<List<String>> candidates, final Collection<String> item, final int fromPos) {
		for (int pos2 = fromPos; pos2 < candidates.size(); pos2++) {
			while (pos2 < candidates.size() && containsPhrase(candidates.get(pos2), (List<String>) item)) {
				candidates.remove(pos2);
			}
		}
	}

	boolean containsPhrase(final List<String> candidateString, final List<String> phrase) {
		List<String> candidate = candidateString;
		final String phraseHead = phrase.get(0);
		int pos = candidate.indexOf(phraseHead);
		while (pos >= 0 && pos < candidate.size() - 1) {
			if (phrase.size() == 1) {
				return true;
			}
			final ListIterator<String> phraseIterator = phrase.listIterator(1);
			candidate = candidate.subList(pos + 1, candidate.size());
			final Iterator<String> candidateIterator = candidate.iterator();

			while (candidateIterator.next().equals(phraseIterator.next())) {
				if (!phraseIterator.hasNext()) {
					return true;
				}
				if (!candidateIterator.hasNext()) {
					break;
				}
			}
			pos = candidate.indexOf(phraseHead);
		}
		return false;
	}

	/**
	 * Give the PhraseType that is most suitable for the item, and update the search space accordingly when the
	 * PhraseType is very general (i.e., a set).
	 * 
	 * @param answer
	 * @param currItem
	 * @param ansResults
	 * @param minPointItems
	 * @return Add the keymatch to the list of results, and update the list of minimal points if the answer is a set
	 *         lookup.
	 */
	PhraseType filterPhraseTypes(final PhraseType answer, final Set<String> currItem,
			final List<PairNC<PhraseType, Set<String>>> ansResults, final List<Set<String>> minPointItems) {
		if (answer != PhraseType.False) {
			ansResults.add(new PairNC<PhraseType, Set<String>>(answer, currItem));
		}
		if (answer == PhraseType.Set) {
			minPointItems.add(currItem);
		}
		return answer;
	}

	// /**
	// * Iteratively test each combination using the given PredicateEvaluator, keeping answers according to logic
	// defined
	// * and implemented in the processAnswer routine, and eliminating candiates that contain a "Set" answer since "set"
	// * has the highest threshold.
	// *
	// * @param initParams
	// * A vector of S (typically String) to evaluate
	// * @param tester
	// * A PredicateEvaluator to tell if a subset is a sufficient representation of a set
	// * @return A list containing the kind of match (set, sequence, exact) and the text of the match
	// */
	//
	// @SuppressWarnings("unchecked")
	// public List<PairNC<PhraseType, Set<String>>> collectMinPointsIteratively(final PredicateEvaluator<String> tester)
	// {
	// return collectMinPointsIteratively(tester.getInput(), tester);
	// }
	//
	// @SuppressWarnings("unchecked")
	// public List<PairNC<PhraseType, Set<String>>> collectMinPointsIteratively(final Collection<String> args,
	// final PredicateEvaluator<String> tester) {
	// return collectMinPointsIteratively(args.toArray((S[]) (new Object[args.size()])), tester);
	// }
	//
	// public List<PairNC<PhraseType, Set<String>>> collectMinPointsIteratively(final S[] args, final
	// PredicateEvaluator<String> tester) {
	// chooser.chooseCombIF(args, true);
	// minPoints = new ArrayList<Set<String>>();
	// final List<PairNC<PhraseType, Set<String>>> resultList = new ArrayList<PairNC<PhraseType, Set<String>>>();
	// while (this._hasNext()) {
	// final LinkedList<Set<String>> candidates = _next();
	// if (candidates.size() == 0) {
	// break;
	// }
	// for (int pos = 0; pos < candidates.size(); pos++) {
	// final Set<String> currItem = new LinkedHashSet<String>(candidates.get(pos));
	// if (subsumed(currItem)) {
	// continue;
	// }
	// processAnswer(tester.getPhraseType(currItem), currItem, resultList, minPoints);
	// }
	// }
	// return resultList;
	// }

}
