// This is unpublished source code. Michah Lerner 2006
// This is unpublished source code. Michah Lerner 2007

package bayesMatchGenerator;

import interfaces.PredicateEvaluator;

import java.util.Collection;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import docStore.DocumentStore;
import docStore.WordStats;

/**
 * <Strong>Essential Function</strong><br>
 * <br>
 * This provides the inner function for valuation of the phrases. The critical function is <code>foundP</code> which
 * evaluates the current <code>groupOfWords</code> relative to the terms it is invoked with.
 * 
 * @author Michah.Lerner
 * 
 */
public class EvaluateCombination implements PredicateEvaluator<String> {
	final private static float lowThreshold = (float) 1e-6;
	final private static boolean db = false;
	final private static PhraseType seqType = PhraseType.Phrase; // PhraseType.Sequence;
	final static int NUMCOMBINATORIALOUTPUTS = 4;

	/**
	 * The groupOfWords is the item that we need to find keyword matches for
	 */
	protected List<String> fullWordSequence;
	/**
	 * The docStore is the document store we are iterating over
	 */
	protected DocumentStore docStore;

	/**
	 * Initialize fields, and invoke the rsp.initControls function to store values from the properties file.
	 * 
	 * @param docStats
	 */
	EvaluateCombination() {
		// Blank
	}

	EvaluateCombination(final DocumentStore docStats) {
		this();
		;
		this.docStore = docStats;
	}

	/**
	 * Set the base case, which is a group of words. Multiple hypotheses will be evaluated to see if they are matches to
	 * it.
	 */
	public void newInput(final Collection<String> words) {
		this.fullWordSequence = (List<String>) words;
	}

	public List<String> getInput() {
		return this.fullWordSequence;
	}

	public float getProbAsSet(final Collection<String> arg) {
		final float prob = docStore.getProbAsSet(fullWordSequence, arg);
		return prob;
	}

	public float getProbAsSequence(final Collection<String> arg) {
		final float prob = docStore.getProbAsSequence(fullWordSequence, arg);
		final float gfactor = WordStats.probA(getInput().size(), arg.size());
		final float result = prob * gfactor;
		return result;
	}

	public float getProbAsPhrase(final Collection<String> arg) {
		final float prob = docStore.getProbAsPhrase(fullWordSequence, arg);
		return prob;
	}

	/**
	 * Method getPhraseType returns PhraseType.false or the most appropriate match type arg given groupOfWords.
	 */

	public MatchInfo getProbPhraseType(final Collection<String> arg) { // Assumes arg is drawn from groupOfWords

		if (arg instanceof Set) {
			final float prob = docStore.getProb(new HashSet<String>(fullWordSequence), (Set<String>) arg);
			if (prob > lowThreshold) {
				if (db) {
					System.out.printf("p(%s | %s) = %5.2f\n", showSet(fullWordSequence), showSet(arg), prob);
				}
				return new MatchInfo(PhraseType.Set, prob);
			}

		} else if (arg instanceof List) {
			float prob;
			if (seqType.equals(PhraseType.Phrase)) {
				prob = docStore.getProbAsPhrase(fullWordSequence, arg);
			} else {
				prob = docStore.getProb(fullWordSequence, (List<String>) arg);
			}
			if (prob > lowThreshold) {
				if (db) {
					System.out.println("p(" + fullWordSequence.toString() + " | " + arg.toString() + ") = " + prob + " (" + seqType
							+ ")");
				}
				return new MatchInfo(seqType, prob);
			}
		}

		return new MatchInfo(PhraseType.False, 0F);

		// // FOLLOWING CODE PROVIDES BIAS FOR WORD OCCURRENCE IN OTHER CORPUS
		// TODO : RENABLE
		// final Double[] combinatorialProb = docStore.getCombinatorialProb(fullWordSequence, arg,
		// combinatorialOutputs);
		// final Set<NCell> datasourceResults = phraseSearchers.expandMulti(fullWordSequence, arg);
		// final KMFeature featureSet = describeAsFeatureset(arg, combinatorialProb, datasourceResults);
		// final Map<CharSequence, Object> featureFSet = mkFeatureSet(arg, combinatorialProb, datasourceResults);
		// // if (true || Constants.traceLevel > 0) {
		// // final String label = arg instanceof Set ? " set" : arg instanceof List ? "seq " : "xxxxxx";
		// // System.out.printf("%20s :: %7.5f %7.5f %7.5f %7.5f [%20s] [%20s]\n", label, combinatorialProb[0],
		// // combinatorialProb[1], combinatorialProb[2], combinatorialProb[3], fullWordSequence.toString(),
		// // arg.toString());
		// // }
		// if (featureSet.equals(KMFeature.NullFeature)) {
		// return DecisionRules.DEFAULTPHASETYPE;
		// }
		// return featureSet.phraseType;
	}

	public void showFeatureMap(final Map<CharSequence, Object> fset) {
		System.out.println("Feature map:");
		for (final Map.Entry<CharSequence, Object> me : fset.entrySet()) {
			System.out.println("$$ " + me.getKey() + " : " + me.getValue());
		}
	}

	String showSet(final Collection<String> coll) {
		final StringBuilder sb = new StringBuilder();
		sb.append("{");
		final Iterator<String> it = coll.iterator();
		while (it.hasNext()) {
			sb.append(it.next());
			if (it.hasNext()) {
				sb.append(", ");
			}
		}
		sb.append("}");
		return sb.toString();
	}
}
