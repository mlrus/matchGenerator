package bayesMatchGenerator;

import interfaces.MatchInfoIF;

public class MatchInfo implements MatchInfoIF {
	PhraseType phraseType;
	float prob;

	/* (non-Javadoc)
	 * @see bayesMatchGenerator.MatchInfoIF#getPhraseType()
	 */
	public PhraseType getPhraseType() {
		return phraseType;
	}

	/* (non-Javadoc)
	 * @see bayesMatchGenerator.MatchInfoIF#getProb()
	 */
	public float getProb() {
		return prob;
	}

	MatchInfo(final PhraseType phraseType, final Number prob) {
		this.phraseType = phraseType;
		this.prob = prob.floatValue();
	}
}
