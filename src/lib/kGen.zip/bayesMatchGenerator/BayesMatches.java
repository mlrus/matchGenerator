// This is unpublished source code. Michah Lerner 2006

package bayesMatchGenerator;

// run with args: -prop C:\mlrus\config.001.xml -DshowAsGened=false -DshowZeros=false -Dexplain=false -DshowAsGened=true
// -DqueryFile=c:\temp\fourInputLines.txt -DtraceLevel=0 C:/TEMP/content.2col -

import interfaces.ContentIteratorIF;
import interfaces.FilterComb;
import interfaces.PredicateEvaluator;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import util.Constants;
import util.Numerics;
import util.coll.PairNC;
import util.coll.Sortable;
import util.data.IO;
import util.data.SummaryStats;
import docStore.DocumentStore;
import docStore.MultilineDocFileIterator;
import docStore.MultilineFileIterator;
import docStore.DocFactory.Doc;

/**
 * <strong>MAJOR CLASS</strong><br>
 * <br>
 * The class <code>BayesMatches</code> is a fully wrapped and executable routine for the heuristic generation of
 * keyword matches that "best" index the input sequences of a <em>DocumentStore</em>. The computations begin
 * selection of high-value keywords, i.e., those with a high information content as measured by comparison of the
 * entropies for the term-sequences of each input sequence. The code computes the
 * <em>low-level a-priori and a-posterior term-set</em> probabilities using both unbiased and heuristic estimators.
 * The specific estimators are configurable through the properties.xml file. <br>
 * <br>
 * The computation proceeds to a <em>weighting and aggregation</em> phase, which combines the low-level scores and
 * introduces a word length bias. A suite of <em>feature detectors</em> generates a <u>symbolic feature set</u> for
 * each item. Certain feature sets also signal the <em>subsumption</em> of some search paths search, when the feature
 * set indicates the (near) certainty of a result and thereby obviates further computation along the subsumable path.
 * <br>
 * <br>
 * that each feature set can be computed without knowledge of any other feature set. The computations share cache for
 * efficiency, but cached values cannot be distinguished from non-cached values. that gets computed. <br>
 * <br>
 * A middle-layer decision process now evaluates the feature sets of each input sequence, through reference to
 * pre-defined criteria. This too is very efficient because it uses simple set operations over pre-defined criteria.
 * Specific output formats are then finalized, and redundant entries are removed prior to writing the results to the
 * output file. <br>
 * <br>
 * All decision-making can be logged, and a suite of configuration parameters allows tuning the software though a
 * persistent configuration file.
 * 
 * @author Michah.Lerner
 * 
 */

public class BayesMatches extends KWIndexProcessor {

	protected DocumentStore docStats;
	private FilterComb<String> filterComb;

	// /**
	// * ChooseCombIF iterates over word combinations in order of increasing size
	// *
	// * @see ChooseCombIF
	// */
	// ChooseCombIF<String> chooser;
	//
	// /**
	// * PredicateEvaluator must implement a predicate <code>foundP</code> that evaluates whether a set of keywords is a
	// * good representative for
	// */
	// PredicateEvaluator<String> evaluator;

	// DecisionRules decisionRules;

	// WordEntropyMaximizer informationConcentrator;

	/**
	 * Standard name for content source
	 */
	static String _contentFilename = "content.2col";

	/**
	 * Configuration variables showStats sets whether to show statistics.
	 */
	public static Boolean showStats = false;

	/**
	 * Configuration variables suppressMatchGeneration suppresses output to allow just statistical computing.
	 */
	public static Boolean suppressMatchGeneration = false;

	/**
	 * Configuration variables allowIterative enables the iterative processing of choices, which saves considerable
	 * space for large word groups, but runs slower for smaller groups. A good tradeoff happens at about seven or eight
	 * elements.
	 */
	public static Boolean allowIterative = true;

	/**
	 * Name of file that has the phrases to process is contentFilename. The KWIndexProcessor uses a different variable,
	 * which we grab.
	 */
	public String contentFilename = KWIndexProcessor.infile;

	static final String labelIdentifier_queryFile = "queryFile", labelIdentifier_corpusCompare = "corpusCompare",
			labelIdentifier_doLogProb = "logProb";
	static final String[] labelIdentifiers = new String[] { labelIdentifier_queryFile, labelIdentifier_corpusCompare };

	/**
	 * Compute the conditional probabilities by iterating over the documents. For every document, this finds the most
	 * important words (<code>informationConcentrator</em>, and sets these words as the newInput
	 * for a <code>validator</code> object.  The validator is then passed into a data collector named either
	 * <code>collectMinPoints</code> or <code>collectMinPointsIteratively</em>.  The data collector runs
	 * the validator over the various possibilities, and this performs the basic and middle-layer computations 
	 * described above.
	 * <br><br>
	 * Several optional processing steps then occur, namely to drop exact matches that are only one token long, and to 
	 * drop longer phrase matches when a shorter phrase match is also generated.  These provide economy of data
	 * representation although it also removes more precise matches and may have a subtle effect upon the relevancy
	 * of retrieved results.
	 * <br><br>
	 * The results for each document are collected together, cross multiplied, and stored into a list of all partial results.
	 *
	 * @param contentIterator an iterator over documents or text lines
	 * @return sorted list of the records that are keyword matches, according to the thresholds for collision and usage probabilities.
	 */

	@SuppressWarnings("unchecked")
	public List<Sortable> computeProbabilities(final ContentIteratorIF contentIterator) {
		final List<Sortable> resultsList = new ArrayList<Sortable>();
		int numItems = 0;
		while (contentIterator.hasNext()) {
			final Doc doc = contentIterator.next();
			final List<String> documentWordlist = doc.getWordlist();
			final long mtime = System.currentTimeMillis();

			final List<PairNC<MatchInfo, Collection<String>>> res = filterComb.collectResults(documentWordlist);
			System.out.printf("PROCESS %5d %20s", numItems++, documentWordlist.toString() + " || " + doc.getRawContent());
			System.out.printf(" ~ %d\n", System.currentTimeMillis() - mtime);
			// if (_dropSequenceSuffixes) {
			// res = dropCoveredPhraseMatches(res);
			// }

			for (final PairNC<MatchInfo, Collection<String>> ss : res) {
				if (ss.s().getProb() > 0f) {
					resultsList.add(new Sortable(doc, ss));
					if (Constants.showAsGened) {
						System.out.println(KeymatchFormatter.mkLine(docStats, doc, ss));
					}
				}
			}

			if (res.size() == 0) {
				final PairNC<MatchInfo, Collection<String>> defaultKM = mkDefaultKM(documentWordlist);
				resultsList.add(new Sortable(doc, defaultKM));
				if (Constants.showAsGened) {
					System.out.println(KeymatchFormatter.mkLine(docStats, doc, defaultKM));
				}
			}
		}

		Collections.sort(resultsList);
		return resultsList;
	}

	/**
	 * Drops phrases from the results, if the phrase is a longer phrase that totally includes some shorter phrase. This
	 * reduces still matches what a standard key matcher will match, although it can impact scoring for some matchers.
	 * 
	 * @param res
	 *            the list of results
	 * @return a modified list of results, where redundant phraseMatches have been dropped.
	 */
	List<PairNC<PhraseType, Collection<String>>> dropCoveredPhraseMatches(final List<PairNC<PhraseType, Collection<String>>> res) {
		final Map<String, PairNC<PhraseType, Collection<String>>> sequences = new TreeMap<String, PairNC<PhraseType, Collection<String>>>(
				Collections.reverseOrder());
		final List<PairNC<PhraseType, Collection<String>>> result = new ArrayList<PairNC<PhraseType, Collection<String>>>();
		for (final PairNC<PhraseType, Collection<String>> ss : res) {
			if (ss.S().equals(PhraseType.Sequence)) {
				sequences.put(ss.T().toString(), ss);
			} else {
				result.add(ss);
			}
		}
		if (sequences.size() < 2) {
			return res;
		}
		String prior = String.valueOf(Character.MAX_VALUE);
		for (final Map.Entry<String, PairNC<PhraseType, Collection<String>>> me : sequences.entrySet()) {
			if (!me.getKey().startsWith(prior)) {
				result.add(me.getValue());
				prior = me.getKey();
				prior = prior.substring(0, prior.length() - 1) + ",";
			} else {
				if (_showDroppedSequenceSuffixes) {
					System.out.println("Dropping specialization \"" + me.getValue().T() + "\", due to more general sequence \""
							+ prior + "\"");
				}
			}
		}
		return result;
	}

	/**
	 * Format the collection of strings into a space separated string.
	 * 
	 * @param col
	 *            a collection of strings
	 * @return a space separated string
	 */
	public String mkString(final Collection<String> col) {
		final StringBuffer sb = new StringBuffer();
		for (final String string : col) {
			sb.append(string + " ");
		}
		if (sb.length() > 1) {
			sb.deleteCharAt(sb.length() - 1);
		}
		return sb.toString();
	}

	/**
	 * Make a keymatch of the default type, which is defined here as a sequence of items.
	 * 
	 * @param words
	 * @return a PairNC consisting of a label (the phrae type) and the words (as set of stirngs)
	 */
	PairNC<MatchInfo, Collection<String>> mkDefaultKM(final Collection<String> words) {
		return new PairNC<MatchInfo, Collection<String>>(new MatchInfo(PhraseType.Sequence, 0.5f), !(words instanceof Set)
				? new LinkedHashSet<String>(words)
				: (Set<String>) words);
	}

	public void summarizeConfiguration() {
		System.out.println("============ configuration =================");
		System.out.println("infile :" + new File(infile).getAbsolutePath());
		if (outfile != null) {
			System.out.println("outfile:" + new File(outfile).getAbsolutePath());
		}
		System.out.println("traceLevel:" + traceLevel);
		System.out.println("stats  :" + showStats);
		System.out.println("threshold_isaSet = " + threshold_isaSet);
		System.out.println("threshold_isaSequence = " + threshold_isaSequence);
		System.out.println("threshold_isaExactmatch =  " + threshold_isaExactmatch);
		System.out.println("subsume=" + subsume);
		System.out.println("adjustifShortWords=" + adjustifShortWords);
		System.out.println("explain=" + explain);
		System.out.println("-------------------");
	}

	public void summarizeResults() {
		System.out.println("\n\nProcessing Summary");
		summarizeConfiguration();
		KeymatchFormatter.summarize(docStats);
	}

	public static void usage() {
		System.out.println("Usage:  java -jar bayesGen [options] inputName outputName");
		System.out
				.println("  inputName with prefix \"_doc\" is special -- says use first expander of <entry key=\"indexNames\"> for input document.");
		System.out.println("  options are  [-prop [propertyFile]] -v[erbose] [-explain] [-st[atistics]]");
		System.out.println("               [-Dproperty=value]");
		System.out.println("  known property names include " + Arrays.asList(labelIdentifiers));
		throw new RuntimeException("Check usage and retry.");
	}

	/**
	 * Invoke optional processing, of the DocumentStore. When there is a property value for the name given by the symbol
	 * <code>labelIdentifier_corpusCompare</code>, the value is the name of a file that should be compared to the
	 * primary docStats. The comparison shows how many documents of a given size are matched to documents with larger
	 * size and intersect all the words of the smaller document.
	 * 
	 * @param dStats
	 */
	public void doOptionalProcessing(final DocumentStore dStats) {
		if (additionalProperties.containsKey(labelIdentifier_doLogProb)) {
			final SummaryStats summaryStats = new SummaryStats();
			summaryStats.describe(dStats, Numerics.range(0, dStats.getCorpusDoccount() - 1), System.out);
		}
		if (additionalProperties.containsKey(labelIdentifier_corpusCompare)) {
			dStats.doCorpusCompare(additionalProperties.get(labelIdentifier_corpusCompare));
		}
	}

	/**
	 * Get the content iterator, either from the document store, or by gluing a file of queries onto the document store.
	 * The document store is contained in the field docStats. The file of queries is defined by the property "queryFile"
	 * (this uses the labelIdentifier_queryFile as a standard variable to contain the actual label).
	 * 
	 * @return An iterator that will return each document in turn. This assures uniform parsing and processing for all
	 *         cases.
	 */
	public ContentIteratorIF<?> getContentIterator() {
		if (additionalProperties.containsKey(labelIdentifier_queryFile)) {
			final MultilineFileIterator i1 = new MultilineFileIterator(additionalProperties.get(labelIdentifier_queryFile));
			final MultilineDocFileIterator i2 = new MultilineDocFileIterator(i1, docStats);
			return i2;
		}
		return docStats.contentIterator;
	}

	/**
	 * The finishInitialization function is a convenience to allocate and prepare the standard items needed for
	 * processing.
	 */
	void finishInitialization() {

		docStats = (new DocumentStore(contentFilename != null
				? contentFilename
				: _contentFilename));

		// informationConcentrator = new WordEntropyMaximizer(docStats);
		// final NBox<String> boxer = new NBox<String>(expander.getExpanderIndexNames());
		// boxer.showColumnNames(System.out);
		//
		// final DecisionRules decisionRules = new DecisionRules();
		final PredicateEvaluator<String> evaluator = new EvaluateCombination(docStats);
		filterComb = new CFilter<String>(evaluator);
		summarizeConfiguration();
	}

	Boolean useFirstExpanderP() {
		if (contentFilename == null) {
			return true;
		}
		if (contentFilename.equalsIgnoreCase("")) {
			return true;
		}
		if (contentFilename.startsWith("_doc")) {
			return true;
		}
		return false;
	}

	/**
	 * Standard placeholder for processing.
	 * 
	 * The doOptionalProcessing will produce, in this case, a list of the words that occur once in the 'small' content
	 * and how many times the word occurs in the the 'large' file. This is usefl because, for example, Campbell occurs
	 * only once in the top N but many times in the full list. The computeProbasbilities iterates over the content to
	 * obtain the accepted results for each document. These get sorted by symbol and then emitted in the format give by
	 * the KeymatchFormatter.
	 */
	public void process() {
		System.out.println(new Date() + " : finish initialization.");
		finishInitialization();
		System.out.println(new Date() + " : start optional processing.");
		doOptionalProcessing(docStats);
		System.out.println(new Date() + " : get content iterator.");
		final ContentIteratorIF<?> contentIterator = getContentIterator();
		System.out.println(new Date() + " : COMPUTATIONS BEGIN.");
		final long startTime = System.currentTimeMillis();
		final List<Sortable> allProbResults = computeProbabilities(contentIterator);
		final long endTime = System.currentTimeMillis();
		System.out.println(new Date() + " : COMPUTATIONS DONE.");
		System.out.println(new Date() + " : emit results.");
		KeymatchFormatter.emit(docStats, allProbResults, out);
		summarizeResults();
		System.out.println(new Date() + " : processing complete.");
		System.out.println(new Date() + " : COMPUTATIONAL PHASE TOOK " + (endTime - startTime) + " milliseconds.");
	}

	/**
	 * Wrapper routine, configures, gets input snad does processing.
	 * 
	 * @throws FileNotFoundException
	 */
	public void processKwIndices() throws FileNotFoundException {
		configureFromPropertyfile(propertyFilename);
		out = IO.safePrintStream(outfile);
		process();
		out.close();
	}

	/**
	 * Main routine, invokes configuration and options processing, and does processing of indices.
	 * 
	 * @param args
	 * @throws FileNotFoundException
	 */
	public void entry(final String args[]) throws FileNotFoundException {
		processArgs(args);
		final BayesMatches processor = new BayesMatches();
		processor.processKwIndices();
	}

	public static void main(final String args[]) throws FileNotFoundException {
		final BayesMatches bayesMatches = new BayesMatches();
		bayesMatches.entry(args);
	}
}
