package bayesMatchGenerator;

public enum PhraseType {
	/**
	 * Set is an unordered collection of items and does not need to match all the terms.
	 */
	Set,
	/**
	 * Sequence is an ordered collection of items, and allows any number of in-between gaps.
	 */
	Sequence,
	/**
	 * Phrase is an ordered continuous collection of items without any in-between gaps.
	 */
	Phrase,
	/**
	 * Exact is an ordered collection of items matched in its entirety
	 */
	Exact,
	/**
	 * False does not match anything
	 */
	False
}