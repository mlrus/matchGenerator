// This is unpublished source code. Michah Lerner 2006

package generators;

import interfaces.Chooser;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import util.Constants;

/**
 * This class provides efficient combinatorial expansion through goal subsumption and bottom up expansion. This gives an
 * iterator to go through the non-subsumed items. For small searches the results are generated at the outset, whereas
 * for small searches the items are generated with a lazy-evaluation that expands the "next" layer only as needed. Both
 * mechanisms are the same in other respects, and in particular they use the same iterator and subsumption (as will be
 * described). <br>
 * <br>
 * The class constructor is called once. It can then process any number of problem instances (i.e., phrases to make
 * keywords for). <br>
 * <br>
 * The method <code>collectMinPoints( phrase, predicate)</code> generates the <em>correct</em> and
 * <em>reasonable</em> constraints and keywords that represent the phrase within the context of the query context. The
 * method may be called repeatedly with different <code>phrase</code>s, in order to obtain results for each phrase.
 * The <code>predicate</code> evaluates whether an item is a good representative of the phrase. The predicate returns
 * a constraint, stating the kind of match (if any) finds the phrase from the item. For example, a "set" constraint
 * works if the item is a subset of the user's query. An "exact" constraint works if the item is exactly the same as the
 * user's query.
 * 
 * <br>
 * <br>
 * To clarify the terms used, <br>
 * <br>
 * <em>Correct</em> keymatches designate non-ambiguous entity identifiers, to within the currently configured
 * threshold of certainty <br>
 * <em>Reasonable</em> keymatches are neither trivial, nor rare. They are what users might reasonably type as a query.
 * <br>
 * The code sets the <em>query context</em> by configuration of two or more information sources. Information sources
 * implement a interface supporting caching and multiplexing of specialized queries to multiple search providers. <br>
 * <em>Keywords</em> are the actual words that the users' queries get matched to, in order to return a result <br>
 * <em>Constraints</em> define the kind of matching that is performed for the given keywords. Different keywords can
 * have different constraints. These correspond the capabilities of the engine that will be used to answer the user
 * queries, such as a GB-series device. <br>
 * <em>Subsumption</em> eliminates the possibilities that do not need to be considered, based on the partial results.
 * This can save substantial space and time. It essentially prunes the search space and often reduces a search space
 * dramatically. Subsumption occurs automatically for items that occur that are probably correct, as defined by the
 * threshold of certainty. Results can be generated even when subsumption does not occur; the results in that case have
 * more restrictive contraints than the more general subsuming results. <br>
 * <em>Lazy evaluation</em> allows searching of fairly large spaces by only generating items when they are needed.
 * This avoids the potentially huge space requirements that can occur when searching for large phrases
 * 
 * @author Michah.Lerner
 * 
 * @param <S>
 */
public class ChooseCombIF<S> implements Chooser<S> {
	public Boolean explain = Constants.explain;
	public Boolean subsume = Constants.subsume;
	S[] items; // current combination being constructed
	S[] data; // input info
	int M, N, P;
	public LinkedList<List<S>> results;
	Iterator<List<S>> instanceIterator = null;

	// List<Set<S>> minPoints; // subsume items with any subset of these horizon points

	public ChooseCombIF() {
		results = new LinkedList<List<S>>();
		// minPoints = new ArrayList<Set<S>>();
		M = N = P = 0;
	}

	@SuppressWarnings("unchecked")
	public ChooseCombIF(final S[] l) {
		results = new LinkedList<List<S>>();
		M = N = P = 0;
		M = l.length;
		data = l;
		for (int n = 1; n <= M; n++) {
			items = (S[]) (new Object[n]);
			choose(M, n);
		}
	}

	public void choose(final int m, final int n) {
		if (n == 0) {
			final List<S> res = new LinkedList<S>();
			for (final S item : items) {
				res.add(item);
			}
			results.add(res);
			return;
		}
		if (m < n) {
			return;
		}
		items[n - 1] = data[m - 1];
		choose(m - 1, n - 1); // with item in position n
		choose(m - 1, n); // without item in position n (overwrite)
		return;
	}

	@SuppressWarnings("unchecked")
	public List<List<S>> chooseCombIF(final S[] l) {
		results = new LinkedList<List<S>>();
		M = N = P = 0;
		M = l.length;
		data = l;
		for (int n = 1; n <= M; n++) {
			items = (S[]) (new Object[n]);
			choose(M, n);
		}
		return results;
	}

	@SuppressWarnings("unchecked")
	public List<List<S>> chooseCombIF(final List<S> c) {
		return chooseCombIF(c.toArray((S[]) (new Object[c.size()])));
	}

	public List<List<S>> permute(final List<S> l) {
		final List<List<S>> rl = new ArrayList<List<S>>();
		if (l.size() == 0) {
			return null;
		}
		if (l.size() == 1) {
			rl.add(l);
			return rl;
		}
		if (l.size() > 1) {
			for (int i = 0; i < l.size(); i++) {
				final S item = l.get(0);
				l.subList(0, 1).clear();
				final List<List<S>> p2 = permute(l);
				for (final List<S> scol : p2) {
					final List<S> res = new ArrayList<S>(scol);
					res.add(item);
					rl.add(res);
				}
				l.add(item);
			}
		}
		return rl;
	}

	// Iterable subsumption version of chooseCombIF
	public List<List<S>> chooseCombIF(final S[] l, boolean iterable) {
		if (!iterable) {
			chooseCombIF(l);
		} else {
			results = new LinkedList<List<S>>();
			M = N = P = 0;
			M = l.length;
			data = l;
			// minPoints = new ArrayList<Set<S>>();
		}
		return results;
	}

	@SuppressWarnings("unchecked")
	public List<List<S>> chooseCombIF(final List<S> c, final boolean iterable) {
		return chooseCombIF(c.toArray((S[]) (new Object[c.size()])), iterable);
	}

	// Iterative lazy expansion
	public List<S> next() {
		if (instanceIterator == null || !instanceIterator.hasNext()) {
			if (!_hasNext()) {
				return null;
			}
			_next();
		}
		return instanceIterator.next();
	}

	public boolean hasNext() {
		if (instanceIterator == null) {
			return _hasNext();
		}
		return instanceIterator.hasNext() || _hasNext();
	}

	public boolean _hasNext() {
		return P < M;
	}

	@SuppressWarnings("unchecked")
	public List<List<S>> _next() {
		results = new LinkedList<List<S>>();
		items = (S[]) (new Object[++P]);
		chooseIncrementally(M, P);
		instanceIterator = results.iterator();
		return results;
	}

	public void chooseIncrementally(final int m, final int n) {
		if (n == 0) {
			final List<S> res = new LinkedList<S>();
			for (final S item : items) {
				res.add(item);
			}
			// if (!subsumed(res)) {
			results.add(res);
			// }
			return;
		}
		if (m < n) {
			return;
		}
		items[n - 1] = data[m - 1];
		chooseIncrementally(m - 1, n - 1); // with item in position n
		chooseIncrementally(m - 1, n); // without item in position n (overwrite)
		return;
	}

	// /**
	// * Test each combination using the given PredicateEvaluator, keeping answers according to logic defined and
	// * implemented in the processAnswer routine, and eliminating candidates that contain a "Set" answer since "set"
	// has
	// * the highest threshold. Subsume the candidate set by eliminating supersets of items that are accepted as sets
	// with
	// * very high probability.
	// *
	// * @param initParams
	// * A vector of S (typically String) to evaluate
	// * @param tester
	// * A PredicateEvaluator to tell if a subset is a sufficient representation of a set
	// * @return A list containing the kind of match (set, sequence, exact) and the text of the match
	// */
	//
	// @SuppressWarnings("unchecked")
	// public List<PairNC<PhraseType, Set<S>>> collectMinPoints(final PredicateEvaluator<S> tester) {
	// return collectMinPoints(tester.getInput(), tester);
	// }
	//
	// @SuppressWarnings("unchecked")
	// public List<PairNC<PhraseType, Set<S>>> collectMinPoints(final Collection<S> args, final PredicateEvaluator<S>
	// tester) {
	// return collectMinPoints(args.toArray((S[]) (new Object[args.size()])), tester);
	// }
	//
	// @SuppressWarnings("unchecked")
	// public List<PairNC<PhraseType, Set<S>>> collectMinPoints(final S[] args, final PredicateEvaluator<S> evaluator) {
	// chooseCombIF(args);
	// final LinkedList<Set<S>> candidates = results;
	// minPoints = new ArrayList<Set<S>>();
	// final List<PairNC<PhraseType, Set<S>>> minpointResults = new ArrayList<PairNC<PhraseType, Set<S>>>();
	// for (int pos = 0; pos < candidates.size(); pos++) {
	// final Set<S> currItem = new LinkedHashSet<S>(candidates.get(pos));
	// final PhraseType pt = evaluator.getPhraseType(currItem);
	// final PhraseType answer = processAnswer(pt, currItem, minpointResults, minPoints);
	// if (subsume && Constants.subsumables.contains(answer)) {
	// for (int pos2 = pos + 1; pos2 < candidates.size(); pos2++) { // ...and remove containing items.
	// while (pos2 < candidates.size() && candidates.get(pos2).containsAll(currItem)) {
	// candidates.remove(pos2);
	// }
	// }
	// }
	// }
	// return minpointResults;
	// }
	//
	// /**
	// * Iteratively test each combination using the given PredicateEvaluator, keeping answers according to logic
	// defined
	// * and implemented in the processAnswer routine, and eliminating candiates that contain a "Set" answer since "set"
	// * has the highest threshold.
	// *
	// * @param initParams
	// * A vector of S (typically String) to evaluate
	// * @param tester
	// * A PredicateEvaluator to tell if a subset is a sufficient representation of a set
	// * @return A list containing the kind of match (set, sequence, exact) and the text of the match
	// */
	//
	// @SuppressWarnings("unchecked")
	// public List<PairNC<PhraseType, Set<S>>> collectMinPointsIteratively(final PredicateEvaluator<S> tester) {
	// return collectMinPointsIteratively(tester.getInput(), tester);
	// }
	//
	// @SuppressWarnings("unchecked")
	// public List<PairNC<PhraseType, Set<S>>> collectMinPointsIteratively(final Collection<S> args, final
	// PredicateEvaluator<S> tester) {
	// return collectMinPointsIteratively(args.toArray((S[]) (new Object[args.size()])), tester);
	// }
	//
	// public List<PairNC<PhraseType, Set<S>>> collectMinPointsIteratively(final S[] args, final PredicateEvaluator<S>
	// tester) {
	// chooseCombIF(args, true);
	// minPoints = new ArrayList<Set<S>>();
	// final List<PairNC<PhraseType, Set<S>>> resultList = new ArrayList<PairNC<PhraseType, Set<S>>>();
	// while (this._hasNext()) {
	// final LinkedList<Set<S>> candidates = _next();
	// if (candidates.size() == 0) {
	// break;
	// }
	// for (int pos = 0; pos < candidates.size(); pos++) {
	// final Set<S> currItem = new LinkedHashSet<S>(candidates.get(pos));
	// if (subsumed(currItem)) {
	// continue;
	// }
	// processAnswer(tester.getPhraseType(currItem), currItem, resultList, minPoints);
	// }
	// }
	// return resultList;
	// }
	//
	// /**
	// * Give the PhraseType that is most suitable for the item, and update the search space accordingly when the
	// * PhraseType is very general (i.e., a set).
	// *
	// * @param answer
	// * @param currItem
	// * @param ansResults
	// * @param minPointItems
	// * @return Add the keymatch to the list of results, and update the list of minimal points if the answer is a set
	// * lookup.
	// */
	// PhraseType processAnswer(final PhraseType answer, final Set<S> currItem, final List<PairNC<PhraseType, Set<S>>>
	// ansResults,
	// final List<Set<S>> minPointItems) {
	// if (answer != PhraseType.False) {
	// ansResults.add(new PairNC<PhraseType, Set<S>>(answer, currItem));
	// }
	// if (answer == PhraseType.Set) {
	// minPointItems.add(currItem);
	// }
	// return answer;
	// }
}

// /**
// * EXAMPLE
// * ********
// * T1 is sample of set validator, with constructor-defined behavior.
// */
// class T1 implements PredicateEvaluator {
// Set<String>itemSet;
// T1(Set<String>itemSet) {
// this.itemSet=itemSet;
// }
// T1(String[]items) {
// itemSet=new HashSet<String>();
// for(String s : items)itemSet.add(s);
// }
// public boolean foundP(Set<String>item) {
// if(item.containsAll(itemSet)) {
// return true;
// }
// return false;
// }
// public boolean foundP(HashSet<String> arg) {
// return foundP((Set<String>)arg);
// }
// }
//	
// /**
// * Sample showing retrieval of combinations that do not contain "one" and "five" (except the first).
// */
// public static void test(String args[]) {
// ChooseCombIF choose = new ChooseCombIF();
// List<Set<String>> res = choose.collectMinPoints(args, choose.new T1(new String[] { "one" ,"five"}));
// System.out.println(res.size()+", "+res);
// }
//	
// public static void main(String args[]) {
// test(args);
// }
