/**
 * 
 */
package docStore;

import interfaces.DocIterator;

import java.util.ListIterator;

import docStore.DocFactory.Doc;

/**
 * Iterator over documents in a document store. Implement the <code>ContentIterator</code> interface.
 * 
 * @author Michah.Lerner
 * 
 */
public class DocumentIterator implements DocIterator {
	// Iterator<Doc>docIterator;
	ListIterator<Doc> docIterator;
	DocumentStore docStats;

	public DocumentIterator(final DocumentStore docStats) {
		// docIterator = docStats.contents.docList.iterator();
		docIterator = docStats.contents.docList.listIterator();
		this.docStats = docStats;
	}

	public boolean hasNext() {
		return docIterator.hasNext();
	}

	public Doc next() {
		return docIterator.next();
	}

	DocumentStore getDocStats() {
		return docStats;
	}
}
