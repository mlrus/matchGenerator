// This is unpublished source code. Michah Lerner 2007

package docStore;

import interfaces.ContentIteratorIF;

import java.util.Collection;

import docStore.DocFactory.Doc;

/**
 * Extends the MultilineFileIterator by also placing each line into the content portion of a docStore. These lines
 * specifically update only the docStore's content portion, but not the statistics. This allows retrieval of the
 * information within a common frame work.
 * 
 * @author Michah.Lerner
 * 
 */

public class MultilineDocFileIterator implements ContentIteratorIF<String> {
	DocumentStore docStore;
	MultilineFileIterator multilineFileIterator;

	/**
	 * Make an iterator over files into document storage
	 * 
	 * @param multilineFileIterator
	 *            the multilineFileIterator that iterates through the new content
	 * @param docStore
	 *            the docStore that should have contents updated for items read (not stats, just content)
	 */
	public MultilineDocFileIterator(final MultilineFileIterator multilineFileIterator, final DocumentStore docStore) {
		this.docStore = docStore;
		this.multilineFileIterator = multilineFileIterator;
	}

	public boolean hasNext() {
		return multilineFileIterator.hasNext();
	}

	public Doc next() {
		final Doc doc = multilineFileIterator.nextDoc();
		docStore.addToContentOnly(doc);
		return doc;
	}

	public Doc updateCurrent(final Collection<String> newContents) {
		throw new UnsupportedOperationException();
	}

	public Doc add(final Doc record) {
		throw new UnsupportedOperationException();
	}

	public boolean hasPrevious() {
		throw new UnsupportedOperationException();
	}

	public Collection<String> previous() {
		throw new UnsupportedOperationException();
	}
}
