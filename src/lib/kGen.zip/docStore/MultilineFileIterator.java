// This is unpublished source code. Michah Lerner 2007

package docStore;

import interfaces.ContentIteratorIF;

import java.util.Collection;
import java.util.Iterator;

import util.data.IO;
import docStore.DocFactory.Doc;

/**
 * The MultilineFileIterator provides an iterator that creates a new Doc object and then returns the string collection
 * which is contained in the new Doc. This ensures that each line will be given the exact same parsinng etc as the items
 * that are pulled into DocumentStore or any other use of the DocFactory.
 * 
 * IT create iterator over a pre-read file contents or collection of string inputs, where the iterator generates a Doc
 * object merely to extract its collection of strings. This ensures uniform preprocessing of strings. See the
 * <code>MultilineDocFileIterator</code> for an iterator that also puts the information into the non-statistical part
 * of a document store.
 * 
 * @author Michah.Lerner
 * 
 */
public class MultilineFileIterator implements ContentIteratorIF<String> {
	public Iterator<String> inputIterator;
	private final DocFactory docFactory;

	public MultilineFileIterator() {
		docFactory = new DocFactory();
	}

	/**
	 * Create an iterator over the pre-read contents of a file, where said iterator generates a Doc object merely to
	 * extract its collection of strings. This ensures uniform preprocessing of strings.
	 * 
	 * @param filename
	 */
	public MultilineFileIterator(final String filename) {
		this(IO.readInput(filename));
	}

	/**
	 * Create iterator over a pre-read collection of string inputs, where said iterator genrates a Doc object merely to
	 * extract its colection of strings. This ensures uniform preprocessing of strings.
	 * 
	 * @param input
	 */
	public MultilineFileIterator(final Collection<String> input) {
		this();
		inputIterator = input.iterator();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see util.ContentIterator#hasNext()
	 */
	public boolean hasNext() {
		return inputIterator.hasNext();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see util.ContentIterator#next()
	 */
	public Doc next() {
		final Doc doc = nextDoc();
		return doc;
	}

	protected Doc nextDoc() {
		final Doc doc = docFactory.mkDoc(inputIterator.next());
		return doc;
	}

	public Doc updateCurrent(final Collection<String> newContents) {
		throw new UnsupportedOperationException();
	}

	public Doc add(final Doc record) {
		throw new UnsupportedOperationException();
	}

	public boolean hasPrevious() {
		throw new UnsupportedOperationException();
	}

	public Collection<String> previous() {
		throw new UnsupportedOperationException();
	}
}
