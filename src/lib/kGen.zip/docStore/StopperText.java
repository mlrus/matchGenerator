// This is unpublished source code. Michah Lerner 2006
// Modified 24JAN2007 to make all comparisons in lower-case only.
// Modified 25JAN2007 to get rid of the above change since it already used a String.CASE_INSENSITIVE_ORDER comparator.
package docStore;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import util.Constants;

/**
 * Stopword removal. Stopwords are defined by a standard list given in this routine, which includes items such as "co",
 * "ltd", "plc" and the interationalized verson of such words. Additional stopwords can be provided as a coma-separated
 * list in the field
 * <code>Constants.additionalStopwords</conde>.  When =the RSP auto-configuration is used to bring values from the config.xml, then
 * the config.xml will override the values through the key <code>additionalStopwords</code> as in this example
 * 	{@literal key="StopperText.additionalStopwords">al,and,asa,company,corp,corporation,del,des,do,fur,group,hld,hldg,holding,holdings,incorporated,limited,new,scrl,und</entry>}
 * 
 * @author Michah.Lerner
 *
 */
public class StopperText {

	public static String additionalStopwords = Constants.additionalStopwords;

	final String phraseSplitterPattern = "\\p{javaWhitespace}";
	private Set<String> stopWords = null;

	Set<String> getStopwords() {
		return stopWords;
	}

	/**
	 * Constructor, builds list of stopwords from constants. These do not need to be lowercased because they are stored
	 * in a treeset with the appropriate comparator.
	 */
	public StopperText() {
		// BayesMatches.rsp.initControls(this);
		stopWords = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
		// for (final String s : new String[] { "ab", "ag", "an", "as", "asa", "bhd", "co", "cv", "de", "di", "el",
		// "es", "hf", "i",
		// "ii", "iii", "kk", "llc", "llp", "ltd", "lp", "n", "no", "nv", "nyrt", "oao", "of", "old", "pcl", "plc",
		// "pt", "s",
		// "sa", "se", "saca", "sicav", "st", "tbk", "the", "v", "y" }) {
		// stopWords.add(s.toLowerCase());
		// }
		if (additionalStopwords != null) {
			for (final String s : additionalStopwords.split(",")) {
				stopWords.add(s.trim());
				System.out.println("added stopword:" + s.trim() + ".");
			}
		}
		show();
	}

	/**
	 * Constructor, builds list of stopwords from content of a file. These do not need to be lowercased because they are
	 * stored in a treeset with the appropriate comparator.
	 */
	public StopperText(final String stopwordFilename) {
		stopWords = new TreeSet<String>(String.CASE_INSENSITIVE_ORDER);
		BufferedReader in = null;
		try {
			String line;
			if (stopwordFilename != null && !stopwordFilename.equals("")) {
				in = new BufferedReader(new FileReader(stopwordFilename));
				while ((line = in.readLine()) != null) {
					stopWords.add(line);
				}
				in.close();
			}
		} catch (final FileNotFoundException e) {
			e.printStackTrace();
		} catch (final IOException e) {
			e.printStackTrace();
		}
		if (in != null) {
			try {
				in.close();
			} catch (final IOException e) {
				e.printStackTrace();
			}
		}
		show();
	}

	/**
	 * Show the stopwords as a list
	 * 
	 */
	void show() {
		if (stopWords != null) {
			System.out.println("stopwords:");
			for (final String s : stopWords) {
				System.out.print(s + "  ");
			}
			System.out.printf("\n-----------------------------\n\n");
		}
	}

	/**
	 * Check if a phrase contains any stopwords
	 * 
	 * @param name
	 *            a word or whitespace-delimited phrase to validate
	 * @return true if it does not contain stopwords, false if stopwords are found in this.
	 */
	boolean okToUse(final String name) {
		// if (name.length() < 2)
		// return false;
		if (stopWords == null) {
			return true;
		}
		for (final String p : name.split(phraseSplitterPattern)) {
			if (stopWords.contains(p)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Eliminate stopwords from the input collection
	 * 
	 * @param input
	 *            A collection of strings that might contain stopwords
	 * @return When the input contains stopwords, this routine returns a new collection without the stopwords. The
	 *         collection will be of the same type as the input collection, if possible. The original collection is
	 *         returned unmodified when it does not have any stopwords in it.
	 * 
	 */
	@SuppressWarnings("unchecked")
	public Collection<String> purgeStopwords(final Collection<String> input) {
		boolean allOK = true;
		for (final String w : input) {
			if (stopWords.contains(w)) {
				allOK = false;
				break;
			}
		}
		if (allOK) {
			return input;
		}
		Collection<String> res = null;
		try {
			res = input.getClass().newInstance();
		} catch (final InstantiationException e) {
			e.printStackTrace();
			return input;
		} catch (final IllegalAccessException e) {
			e.printStackTrace();
			return input;
		}
		for (final String s : input) {
			if (okToUse(s)) {
				res.add(s);
			}
		}
		return res;
	}

	/**
	 * Given a string, return another string without the stopwords
	 * 
	 * @param input
	 *            a string which might include space-delimited stopwords
	 * @return a string which does not include the space-delimited stopwords
	 */
	public String purgeStopwords(final String input) {
		final StringBuffer sb = new StringBuffer();
		for (final String s : input.split(phraseSplitterPattern)) {
			if (!stopWords.contains(s)) {
				sb.append(s + " ");
			}
		}
		if (sb.length() > 0) {
			sb.deleteCharAt(sb.length() - 1);
		}
		if (input.equals(sb)) {
			return input;
		}
		return sb.toString();
	}

	/**
	 * Given an array or vararg of string, given a sequence of strings as input
	 * 
	 * @param input
	 *            a vararg array of string which might include space-delimited stopwords
	 * @return a list with all inputs except those in the stopword list
	 */
	public List<String> purgeStopwords(final String... input) {
		final List<String> result = new ArrayList<String>();
		for (final String s : input) {
			if (!stopWords.contains(s)) {
				result.add(s);
			}
		}
		return result;
	}

	/**
	 * Given a list of strings, given a sequence of strings as input
	 * 
	 * @param input
	 *            a vararg array of string which might include space-delimited stopwords
	 * @return a list with all inputs except those in the stopword list
	 */
	public List<String> purgeStopwords(final List<String> input) {
		final List<String> result = new ArrayList<String>();
		for (final String s : input) {
			if (!stopWords.contains(s)) {
				result.add(s);
			}
		}
		return result;
	}

}