// This is unpublished source code. Michah Lerner 2006

package docStore;

import interfaces.ContentIteratorIF;

import java.util.Collection;

import docStore.DocFactory.Doc;

/**
 * Iterator over documents in a document store. Implement the <code>ContentIterator</code> interface.
 * 
 * @author Michah.Lerner
 * 
 */
public class DocumentsContentIterator implements ContentIteratorIF<DocumentStore> {
	DocumentIterator docIterator;
	Doc curr = null;

	public DocumentsContentIterator(final String filename) {
		this(new DocumentStore(filename));
	}

	public DocumentsContentIterator(final DocumentStore docStats) {
		docIterator = new DocumentIterator(docStats);
	}

	public boolean hasNext() {
		return docIterator.hasNext();
	}

	public Doc next() {
		curr = docIterator.next();
		return curr;
	}

	public Doc updateCurrent(final Collection<String> newContents) {
		final StringBuilder sb = new StringBuilder();
		for (final String s : newContents) {
			sb.append(s + " ");
		}
		if (sb.length() > 0) {
			sb.deleteCharAt(sb.length() - 1);
		}
		final String newContent = sb.toString();
		final String handle = curr.getHandle();
		curr.valid = false;

		return add(docIterator.getDocStats().docFactory.doc(newContent, handle));
	}

	public Doc add(final Doc doc) {
		docIterator.docStats.halfAdd(doc);
		// docIterator.docIterator.add(doc);
		return doc;
	}

	public boolean hasPrevious() {
		return docIterator.docIterator.hasPrevious();
	}

	public Collection<String> previous() {
		return docIterator.docIterator.previous().getWordlist();
	}
}
