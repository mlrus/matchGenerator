package docStore;

import java.util.ArrayList;
import java.util.List;

/***********************************************************************************************************************
 * The methods in WordStats give an improved models for: p(d | length(d=n), length(h=m)
 * 
 * @author mlrus
 * 
 */
public class WordStats {

	static long twoPow(final int n) {
		long ans = 1;
		for (int i = 0; i < n; i++) {
			ans *= 2;
		}
		return ans;
	}

	static long sumfreqMchooseN(final int m, final int n) {
		return twoPow(m - n);
	}

	static long sumAllchoices(final int m) {
		return twoPow(m) - 1;
	}

	static float dProb(final int m, final int n) {
		final long allChoices = twoPow(m) - 1;
		final long thisChoice = twoPow(m - n);
		final float ans = (float) thisChoice / (float) allChoices;
		return ans;
	}

	static List<Long> fact = new ArrayList<Long>();
	static {
		fact.add(1L);
		fact.add(1L);
	}

	static long fact(final int n) {
		while (fact.size() <= n) {
			fact.add(fact.size() * fact.get(fact.size() - 1));
		}
		return fact.get(n);
	}

	public static long bincoef(final int m, final int n) {
		if (m == n) {
			return 1;
		}
		return fact(m) / fact(m - n) / fact(n);
	}

	public static float probA(final int m, final int n) {
		return dProb(m, n);
	}

	public static float invBinCoef(final int m, final int n) {
		return 1F / bincoef(m, n);
	}

	public static void main(final String[] args) {
		int M;
		if (args.length == 0) {
			M = 3;
		} else {
			M = Integer.parseInt(args[0]);
		}
		final int[] t = new int[M + 1];
		for (int i = 0; i <= M; i++) {
			t[i] = 0;
		}
		for (int m = 1; m <= M; m++) {
			for (int n = 1; n <= m; n++) {
				t[n] += twoPow(m - n);
				System.out.printf(
						"group(%d) in combs(%d)  ::  sum(occurrences)=%d  ::  sum[p(group(%d) | %d)] = %7.5f  :: quot=%7.5f,%7.5f"
								+ "\n", n, m, twoPow(m - n), n, m, dProb(m, n), probA(m, n), invBinCoef(m, n));
				// (double) bincoef(m, n) / twoPow(m - 1));
			}
		}
		System.out.println();
		for (int i = 0; i < M; i++) {
			System.out.printf("%d :: %4d   and (%d %d)=%d\n", i, t[i], M, i, bincoef(M, i));
		}
	}
}
