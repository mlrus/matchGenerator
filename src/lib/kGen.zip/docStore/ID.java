// This is unpublished source code. Michah Lerner 2006

package docStore;

import interfaces.IID;

/**
 * Generator of unique transient identifiers with lifetime of the process.
 * 
 * @author Michah.Lerner
 * 
 */
public final class ID implements IID {
	int cnt = 0;

	public// synchronized
	int next() {
		return cnt++;
	}
}