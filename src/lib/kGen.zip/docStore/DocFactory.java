// This is unpublished source code. Michah Lerner 2006

package docStore;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;

import util.data.DropWordsIf;
import util.data.Tkn;

/**
 * Factor for documents. Items without id will be assigned a unique (but transient to this invocation) identifier.
 * 
 * @author Michah.Lerner
 * @see DocIterator
 * @see DocumentStore
 */
public class DocFactory {
	public ID id;
	public StopperText stopperText;
	public Tkn tkn;

	// public WordID wordID;

	public DocFactory() {
		this(new ID(), new StopperText(), new Tkn());
	}

	public DocFactory(final ID id, final StopperText stopperText, final Tkn tkn) {
		this.id = id;
		this.stopperText = stopperText;
		this.tkn = tkn;
		// this.wordID = new WordID();
		;
	}

	public Doc mkDoc(final String line) {
		Doc doc = null;
		final String l[] = line.split(",", 2);
		if (l.length == 1) {
			doc = doc(l[0]);
		} else {
			doc = doc(l[1], l[0]);
		}
		return doc;
	}

	public Doc doc(final String content, final String handle) {
		return new Doc(content, handle);
	}

	public Doc doc(final String content) {
		return new Doc(content, null);
	}

	final public class Doc {
		public final Integer docID;
		final String rawContent;
		final String handle;
		final ArrayList<String> wl;
		final WordSet wb;
		final ArrayList<String> wlPreserveCase;
		volatile boolean valid = true;

		Doc(final String content, final String handle) {
			docID = id.next();
			this.rawContent = content;
			final List<String> unstoppedLine = new ArrayList<String>(Arrays.asList(tkn.za(content)));
			final ListIterator<String> li = unstoppedLine.listIterator();
			while (li.hasNext()) {
				if (li.next().contains(",")) {
					li.set(li.previous().replaceAll(",", ""));
				}
			}
			final List<String> stoppedLine = stopperText.purgeStopwords(unstoppedLine);
			DropWordsIf.dropWordsIf(stoppedLine);

			this.handle = handle;
			wlPreserveCase = new ArrayList<String>(stoppedLine);
			wlPreserveCase.trimToSize();
			wl = new ArrayList<String>();
			for (final String s : wlPreserveCase) {
				// wordID.addWord(s);
				wl.add(s.toLowerCase(Locale.getDefault()));
			}
			wl.trimToSize();
			wb = new WordSet(wl);
		}

		@Override
		public String toString() {
			return String.format("ID=%d rawContent=\"%s\" handle=\"%s\" wl=%s wb=%s wlPreserveCase=%s\n", docID, rawContent,
					handle, wl, wb, wlPreserveCase);
		}

		Doc(final String content) {
			this(content, null);
		}

		int getDocID() {
			return docID;
		}

		public String getHandle() {
			return handle;
		}

		public String getRawContent() {
			return rawContent;
		}

		List<String> getAllTokens() {
			return Arrays.asList(tkn.za(rawContent));
		}

		public ArrayList<String> getWordlist() {
			return wl;
		}

		public WordSet getWordset() {
			return wb;
		}

		public ArrayList<String> getWordlistOrig() {
			return wlPreserveCase;
		}
	}
}