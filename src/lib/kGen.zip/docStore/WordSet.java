//This is unpublished source code. Michah Lerner 2006

package docStore;

import java.util.Collection;
import java.util.HashSet;

/**
 * The class <class>WordSet</class> provides a distinguished class name for 
 * storage of Set of words. 
 * A <class>WordSet</class> 
 * cannot inadvertently reference other kinds of sets. The method  in other
 * respects is like a <class>HashSet</class>. It can receive a <class>HashSet</class>
 * by casting.
 * @author Michah.Lerner
 *
 */
@SuppressWarnings("serial")
public class WordSet extends HashSet<String> {
	public WordSet() {
		super();
	}

	public WordSet(Collection<String> l) {
		addAll(l);
	}

}