// This is unpublished source code. Michah Lerner 2006

package docStore;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.ListIterator;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import match.MSAstring;
import match.StringEntry;
import util.Constants;
import util.Numerics;
import util.coll.BoundedLinkedHashMap;
import util.coll.Sortable;
import util.count.Tally;
import util.count.TallyCList;
import util.count.TallyCSet;
import docStore.DocFactory.Doc;

public class DocumentStore {

	boolean debug = false;

	final static String tokenPatternString = "[\\p{L}0-9_]+"; // "[\\S]+";
	final static String delimPattString = "[^\\p{L}0-9_]+";
	final static int numDataColumns = 2;
	final static int _siz = 10000;
	// final static int colIndexToUse = 3;
	final static int[] colIndicesToUse = new int[] { 0, 1 };
	static Integer numUniqueWords, numContentWords, numDocuments;
	public Double invNumwords;
	public Double invNumDocuments;
	public DocFactory docFactory;
	public DocumentsContentIterator contentIterator;
	private final BoundedLinkedHashMap<Set<String>, Collection<Integer>> instanceCache;
	public Integer outputColumns;
	public int numLinesInput;
	public Boolean validateFrequencies = false; // testpoint activation -- ensure the frequencies correspond to the
	// names, despite hashing
	public Content contents;
	public Stat stats;

	static public MSAstring msa = new MSAstring();

	// public SimpleFischerKernel simpleFischerKernel;

	public DocumentStore() {

		numLinesInput = 0;
		outputColumns = 120;
		instanceCache = new BoundedLinkedHashMap<Set<String>, Collection<Integer>>(Constants._documentStore_cacheSize,
				Constants._documentStore_cacheLoadFactor, true);
		docFactory = new DocFactory();
		contents = new Content();
		stats = new Stat();
		// simpleFischerKernel = new SimpleFischerKernel();
	}

	public DocumentStore(final String filename) {
		this(ContentIterator.get(filename));
		// this(new ContentIterator(filename, numDataColumns, DocumentStore.colIndicesToUse).getContents());
	}

	public DocumentStore(final String filename, final int[] colIndicesToUse) {
		this(ContentIterator.get(filename, colIndicesToUse));
		// this(new ContentIterator(filename, numDataColumns, colIndicesToUse).getContents());
	}

	// public DocumentStore(final Collection<String> lines) {

	public DocumentStore(final Iterator<String> it) {
		this();
		while (it.hasNext()) {
			add(it.next());
		}

		for (final Doc doc : this.contents.docList) {
			final String ident = doc.getHandle();

			final Iterator<String> iter = doc.wl.iterator();
			final StringBuffer sb = new StringBuffer();
			while (iter.hasNext()) {
				sb.append(iter.next());
				if (iter.hasNext()) {
					sb.append(" ");
				}
			}
			// Normalize escaped special characters.
			final String content = sb.toString();// .replaceAll("\\\\.", " ");
			final StringEntry se = new StringEntry(ident, content);
			msa.addEntry(se);
		}
		msa.makeSuffixArray();
		msa.lsa();

		// docFactory.wordID.renumber();
		contentIterator = new DocumentsContentIterator(this);
		// numUniqueWords = docFactory.wordID.vocabSize();
		numContentWords = getCorpusWordcount();
		numDocuments = getCorpusDoccount();
		invNumDocuments = 1D / numDocuments;
		// invNumwords = 1D / (1D * numUniqueWords);
		System.out.printf("numItemWarnings=%d numUniqueWords=%d numContentWords=%d numDocuments=%d invNumwords=%f\n",
				contents.numItemWarnings, numUniqueWords, numContentWords, numDocuments, invNumwords);
		stats.tfidf = stats.mkTfidf();
	}

	/**
	 * RankMap word &rarr; count
	 */
	@SuppressWarnings("serial")
	public class RankMap extends HashMap<String, Integer> {
		// empty
	}

	/**
	 * FreqMap count &rarr; {words with count}
	 * 
	 * @author Michah.Lerner
	 * 
	 */
	@SuppressWarnings("serial")
	public class FreqMap extends LinkedHashMap<Integer, Set<String>> {
		// currently empty
	}

	void add(final String line) {
		add(docFactory.mkDoc(line));
	}

	Doc add(final Doc doc) {
		contents.add(doc);
		stats.add(doc);
		return doc;
	}

	Doc halfAdd(final Doc doc) {// B
		contents.halfAdd(doc);
		stats.add(doc);
		return doc;
	}

	void addAll(final Collection<String> lines) {
		for (final String line : lines) {
			add(line.trim());
			numLinesInput++;
		}
	}

	void addToContentOnly(final Doc doc) {
		contents.add(doc);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see util.D#sumWordCounts(java.util.Collection)
	 */
	public int sumWordCounts(final Collection<String> words) {
		int sum = 0;
		for (final String s : words) {
			final Integer i = stats.wordCount.get(s);
			if (i != null) {
				sum += i;
			}
		}
		return sum;
	}

	/**
	 * Return total word word count, including duplicates.
	 * 
	 * @return total word count
	 */
	public int getCorpusWordcount() {
		return stats.getCorpusWordcount();
	}

	/**
	 * Return number of documents.
	 * 
	 * @return number of documents
	 */
	public int getCorpusDoccount() {
		return stats.getCorpusDoccount();
	}

	public Integer getCorpusUniqueWordcount() {
		return null;
	}

	public Double getEntropy() {
		return stats.getEntropy();
	}

	public Double getGroupEntropy(final Collection<String> words) {
		return stats.getGroupEntropy(words);
	}

	public Double getDocEntropy(final Collection<String> words) {
		return stats.getDocEntropy(words);
	}

	public Double getEntropy(final Collection<String> words) {
		return stats.getEntropy(words);
	}

	public Double getEntropy(final String word) {
		return stats.getEntropy(word);
	}

	public Map<String, Integer> getWordCount() {
		return stats.wordCount.get();
	}

	public Integer getWordCount(final String s) {
		if (validateFrequencies) {
			System.out.println("VALIDATION FOR ALL WORDS IN STORE GIVES : " + stats.wordCount.validate());
		}
		return stats.wordCount.get(s);
	}

	public Double[] getCombinatorialProb(final List<String> groupOfWords, final List<String> arg) {
		final Double[] gcp = getCombinatorialProb(groupOfWords, arg, new Double[4]);
		return gcp;
	}

	/*******************************************************************************************************************
	 * Compute the probability vector such as [1.0, 2.0, 0.5, 1.0] (a) the words of set "arg" (as a set) given a
	 * document that has words as set "group" (b) the words of sequence "arg" (as an ordered set), given a document that
	 * has words as set "group" (c) the words of set "arg" (as a set) given a document that has words as seq "group" (d)
	 * the words of sequence "arg" (as an ordered set), given a document that has words as seq "group" For example,
	 * [merrill, lynch] also occurs as [merrill ly.new egy], yielding asymmetric results [1.0, 1.0333333333333334,
	 * 0.967741935483871, 1.0]
	 * 
	 * @param groupOfWords
	 *            the full entity name in the correct order
	 * @param arg
	 *            a piece of the entity name in the correct order
	 * @param astore
	 *            a vector to receive the result
	 * @param doboth
	 * @return probability vector such as [1.0, 2.0, 0.5, 1.0] (which is symmetric viz group or arg) or a probability
	 *         vector such as [1.0, 1.0333333333333334, 0.967741935483871, 1.0] (merrill lynch)
	 */
	public Double[] getCombinatorialProb(final Collection<String> groupOfWords, final Collection<String> arg, final Double[] ans) {

		int argSetCount = 0, argSeqCount = 0, groupSetCount = 0, groupSeqCount = 0;
		Arrays.fill(ans, 0D);

		final Collection<Integer> docsWithGroupSET = getDocidsHavingSET(groupOfWords);
		final Collection<Integer> docsWithArgSET = getDocidsHavingSET(arg);
		final Collection<Integer> docsWithGroupSEQ = getDocidsHavingSEQ(groupOfWords);
		final Collection<Integer> docsWithArgSEQ = getDocidsHavingSEQ(arg);
		groupSetCount = docsWithGroupSET == null
				? 0
				: docsWithGroupSET.size();
		argSetCount = docsWithArgSET == null
				? 0
				: docsWithArgSET.size();
		groupSeqCount = docsWithGroupSEQ == null
				? 0
				: docsWithGroupSEQ.size();
		argSeqCount = docsWithArgSEQ == null
				? 0
				: docsWithArgSEQ.size();
		if (argSetCount > 0) {
			ans[0] = (double) groupSetCount / argSetCount;
		}

		if (argSeqCount > 0) {
			ans[3] = (double) groupSeqCount / argSeqCount;
		}
		return ans;
	}

	public float getProb(final Set<String> groupOfWords, final Set<String> arg) {
		final Collection<Integer> docsWithArgSET = getDocidsHavingSET(arg);
		final int argSetCount = docsWithArgSET == null
				? 0
				: docsWithArgSET.size();
		final Collection<Integer> docsWithBoth = keepDocsWithSet(docsWithArgSET, groupOfWords);
		final int groupSetCount = docsWithBoth == null
				? 0
				: docsWithBoth.size();
		final float ans = argSetCount == 0
				? 0
				: (float) groupSetCount / argSetCount;
		if (debug) {
			System.out.println("+++++set      prob :: count(group " + showSet(groupOfWords) + ")=" + groupSetCount + "; count("
					+ showSet(arg) + ")=" + argSetCount);
		}
		return ans;
	}

	public float getProb(final List<String> groupOfWords, final List<String> arg) {
		final Collection<Integer> docsWithArgSEQ = getDocidsHavingSEQ(arg);
		final int argSeqCount = docsWithArgSEQ == null
				? 0
				: docsWithArgSEQ.size();
		final Collection<Integer> docsWithBoth = keepDocsWithSeq(docsWithArgSEQ, groupOfWords);
		final int groupSeqCount = docsWithBoth == null
				? 0
				: docsWithBoth.size();
		final float ans = argSeqCount == 0
				? 0
				: (float) groupSeqCount / argSeqCount;
		if (debug) {
			System.out.println("+++++sequence prob :: count(group " + groupOfWords.toString() + ")=" + groupSeqCount + "; count("
					+ arg + ")=" + argSeqCount);
		}
		return ans;
	}

	public float probAsGroup(final Collection<Integer> docsWithSet, final Collection<Integer> docsWithBoth,
			final Collection<String> arg) {
		long totalWithSetInstance = 0;
		long totalWithSetUniverse = 0;
		for (final Integer docid : docsWithSet) {
			final List<String> content = getContent(docid);
			final long nOccurs = WordStats.sumfreqMchooseN(content.size(), arg.size());
			final long allOcc = WordStats.sumAllchoices(content.size());
			totalWithSetInstance += nOccurs;
			totalWithSetUniverse += allOcc;
		}

		long totalWithBothInstance = 0;
		long totalWithBothUniverse = 0;
		for (final Integer docid : docsWithBoth) {
			final List<String> content = getContent(docid);
			final long nOccurs = WordStats.sumfreqMchooseN(content.size(), arg.size());
			final long allOcc = WordStats.sumAllchoices(content.size());
			totalWithBothInstance += nOccurs;
			totalWithBothUniverse += allOcc;
		}

		final float modelProb = totalWithSetUniverse == 0
				? 0F
				: ((float) totalWithBothInstance / (float) totalWithSetUniverse);
		return modelProb;
	}

	BoundedLinkedHashMap<Collection<String>, Integer> mCache = new BoundedLinkedHashMap<Collection<String>, Integer>(
			Constants._documentStore_cacheSize, Constants._documentStore_cacheLoadFactor, true);
	BoundedLinkedHashMap<Collection<String>, Integer> pCache = new BoundedLinkedHashMap<Collection<String>, Integer>(
			Constants._documentStore_cacheSize, Constants._documentStore_cacheLoadFactor, true);

	BoundedLinkedHashMap<Collection<String>, BitSet> p2Cache = new BoundedLinkedHashMap<Collection<String>, BitSet>(
			Constants._documentStore_cacheSize, Constants._documentStore_cacheLoadFactor, true);

	public float getProbAsSet(final Collection<String> groupOfWords, final Collection<String> arg) {
		float ans;
		if (!Constants.useSA) {

			final Collection<Integer> docsWithArgSET = getDocidsHavingSET(arg);
			final int argSetCount = docsWithArgSET == null
					? 0
					: docsWithArgSET.size();
			final Collection<Integer> docsWithBoth = keepDocsWithSet(docsWithArgSET, groupOfWords);
			final int groupSetCount = docsWithBoth == null
					? 0
					: docsWithBoth.size();
			final float prob = argSetCount == 0
					? 0
					: (float) groupSetCount / argSetCount;

			final float gfactor = WordStats.probA(groupOfWords.size(), arg.size());
			final float result = prob * gfactor;
			ans = result;
		}

		if (Constants.useSA || Constants.testSA) {
			int groupSetCount, argSetCount;
			BitSet bs;

			if (mCache.containsKey(arg)) {
				argSetCount = mCache.get(arg);
			} else {
				bs = msa.BSgetAllWords(arg.iterator());
				argSetCount = bs.cardinality();
				mCache.put(arg, argSetCount);
			}

			if (mCache.containsKey(groupOfWords)) {
				groupSetCount = mCache.get(groupOfWords);
			} else {
				bs = msa.BSgetAllWords(groupOfWords.iterator());
				groupSetCount = bs.cardinality();
				mCache.put(groupOfWords, groupSetCount);
			}

			final float prob = (float) groupSetCount / argSetCount;
			final float gfactor = WordStats.probA(groupOfWords.size(), arg.size());
			final float result = prob * gfactor;

			if (Constants.useSA) {
				ans = result;
			}
		}

		return ans;
	}

	public float getProbAsSequence(final Collection<String> groupOfWords, final Collection<String> arg) {
		final Collection<Integer> docsWithArgSEQ = getDocidsHavingSEQ(arg);
		final int argSeqCount = docsWithArgSEQ == null
				? 0
				: docsWithArgSEQ.size();
		final Collection<Integer> docsWithBoth = keepDocsWithSeq(docsWithArgSEQ, groupOfWords);
		final int groupSeqCount = docsWithBoth == null
				? 0
				: docsWithBoth.size();
		final float ans = argSeqCount == 0
				? 0
				: (float) groupSeqCount / argSeqCount;
		if (debug) {
			System.out.println("+++++sequence getProbAsSequence :: count(group " + groupOfWords.toString() + ")=" + groupSeqCount
					+ "; count(" + arg + ")=" + argSeqCount);
		}
		return ans;
	}

	public float getProbAsPhrase(final Collection<String> groupOfWords, final Collection<String> arg) {
		if (true) {
			System.exit(0);
		}
		float ans;
		if (!Constants.useSA) {

			final List<Integer> docsWithArgPHR = getDocidsHavingPHRASE(arg);
			final int argPhrCount = docsWithArgPHR == null
					? 0
					: docsWithArgPHR.size();
			final Collection<Integer> docsWithBoth = keepDocsWithPhr(docsWithArgPHR, groupOfWords);
			final int groupPhrCount = docsWithBoth == null
					? 0
					: docsWithBoth.size();
			ans = argPhrCount == 0
					? 0
					: (float) groupPhrCount / argPhrCount;
			if (true || debug) {
				System.out.println("+++++phrase prob :: count(group " + groupOfWords.toString() + ")=" + groupPhrCount + "; count("
						+ arg + ")=" + argPhrCount);
			}
		}

		if (Constants.useSA || Constants.testSA) {
			BitSet bs;
			final BitSet bs2;

			final StringBuffer sb = new StringBuffer();
			final Iterator<String> it = arg.iterator();
			while (it.hasNext()) {
				sb.append(it.next());
				if (it.hasNext()) {
					sb.append(" ");
				}
			}

			bs = msa.BSgetPhrase(sb.toString());
			final int argPhrCount = bs.cardinality();

			if (p2Cache.containsKey(groupOfWords)) {
				bs2 = p2Cache.get(groupOfWords);
			} else {
				bs2 = msa.BSgetAllWords(groupOfWords.iterator());
				p2Cache.put(groupOfWords, bs2);
			}
			final int groupPhrCount = bs2.cardinality();

			bs.and(bs2);
			final int resultCount = bs.cardinality();

			if (Constants.testSA) {
				System.out.printf("#phrase counts %4d %4d %4d for \"" + sb.toString() + "\"\n", argPhrCount, groupPhrCount,
						resultCount);
			}

			final float prob = (float) groupPhrCount / argPhrCount;

			if (Constants.useSA) {
				ans = prob;
			}
		}

		return ans;
	}

	String showSet(final Collection<String> coll) {
		final StringBuilder sb = new StringBuilder();
		sb.append("{");
		final Iterator<String> it = coll.iterator();
		while (it.hasNext()) {
			sb.append(it.next());
			if (it.hasNext()) {
				sb.append(", ");
			}
		}
		sb.append("}");
		return sb.toString();
	}

	// // // Pr(subsequence|group)
	// if (argSeqCount > 0) {
	// ans[1] = (double) groupSetCount / argSeqCount;
	// }
	// //
	// // // Pr(subset|insequenceGroup)
	// if (argSetCount > 0) {
	// ans[2] = (double) groupSeqCount / argSetCount;
	// }

	// Pr(subsequence|insequenceGroup)
	// if (argSeqCount > 0) {
	// ans[3] = (double) groupSeqCount / argSeqCount;
	// }
	//
	// return ans;
	// }

	public Double[] bayesProbs(final Collection<String> fullPhrase, final Collection<String> partPhrase, final Double[] ans) {
		Double[] result;
		if (ans != null && ans.length >= 4) {
			Arrays.fill(ans, 0D);
			result = ans;
		} else {
			result = new Double[4];
		}
		int nPartial = 0, argSeqCount = 0, nFull = 0, groupSeqCount = 0;

		final Collection<Integer> docsWithFullPhrase = getDocidsHavingSET(fullPhrase);
		final Collection<Integer> docsWithPartPhrase = getDocidsHavingSET(partPhrase);
		nFull = docsWithFullPhrase == null
				? 0
				: docsWithFullPhrase.size();
		nPartial = docsWithPartPhrase == null
				? 0
				: docsWithPartPhrase.size();
		if (nFull + nPartial == 0) {
			return ans;
		}
		final Collection<Integer> docsWithArgSeq = partPhrase.size() == 1
				? docsWithPartPhrase
				: collectIfSameSequence(partPhrase, docsWithPartPhrase);
		final Collection<Integer> docsWithGroupSeq = partPhrase.size() == 1
				? docsWithFullPhrase
				: collectIfSameSequence(partPhrase, docsWithFullPhrase);
		argSeqCount = docsWithArgSeq == null
				? 0
				: docsWithArgSeq.size();
		groupSeqCount = docsWithGroupSeq == null
				? 0
				: docsWithGroupSeq.size();

		int itemno = 0;

		// p(d|H)p(H)/p(d)
		final double probDataGivenHypothesis = 1D;
		final double probHypothesis = 1D / contents.docList.size();

		// Pr(subset|group)
		if (nPartial > 0) {

			ans[itemno++] = (double) nFull / nPartial;
		}

		// // Pr(subsequence|group)
		// if(argSeqCount>0)
		// ans[1] = (Double)groupSetCount / argSeqCount;
		//
		// // Pr(subset|insequenceGroup)
		// if(argSetCount>0)
		// ans[2] = (Double)groupSeqCount / argSetCount;

		// Pr(subsequence|insequenceGroup)
		if (argSeqCount > 0) {
			ans[itemno++] = (double) groupSeqCount / argSeqCount;
		}

		return ans;
	}

	/*******************************************************************************************************************
	 * Retrieve in-sequence documents. Stronger than a set, weaker than a phrase
	 * 
	 * @param docIdSequence
	 * @param docsWithPartPhrase
	 * @return contents of documents of docList containing the sequence contentSeq
	 */
	private Collection<Integer> collectIfSameSequence(final Collection<String> contentSeq,
			final Collection<Integer> docsWithPartPhrase) {
		final Collection<Integer> sameSeqDocs = new ArrayList<Integer>();
		for (final Integer docID : docsWithPartPhrase) {
			final Collection<String> docContent = getContent(docID);
			if (appearInSameSequence(docContent, contentSeq)) {
				sameSeqDocs.add(docID);
			}
		}
		return sameSeqDocs;
	}

	public boolean appearInSameSequence(final Collection<String> docContent, final Collection<String> arg) {
		final Iterator<String> docContentIterator = docContent.iterator();
		final Iterator<String> argValuesIterator = arg.iterator();
		String inDoc, inArg;

		while (argValuesIterator.hasNext() && docContentIterator.hasNext()) {
			inArg = argValuesIterator.next();
			inDoc = docContentIterator.next();
			while (!inArg.equalsIgnoreCase(inDoc)) {
				if (!docContentIterator.hasNext()) {
					return false; // not all matched
				}
				inDoc = docContentIterator.next();
			}
			if (!argValuesIterator.hasNext()) {
				return true;
			}
		}
		return false;
	}

	Integer countWordOccurences(final String s) {
		int occ = 0;
		for (final Doc doc : contents.docList) {
			for (final String word : doc.getWordlist()) {
				if (s.equals(word)) {
					occ++;
				}
			}
		}
		return occ;
	}

	Integer countWordOccurencesIgnoreCase(final String s) {
		int occ = 0;
		for (final Doc doc : contents.docList) {
			for (final String word : doc.getWordlist()) {
				if (s.equalsIgnoreCase(word)) {
					occ++;
				}
			}
		}
		return occ;
	}

	Integer countDocsHaving(final String s) {
		int occ = 0;
		for (final Doc doc : contents.docList) {
			if (doc.getWordset().contains(s)) {
				occ++;
			}
		}
		return occ;
	}

	public Integer countDocsHaving(final Collection<String> s) {
		int occ = 0;
		for (final Doc doc : contents.docList) {
			if (doc.getWordset().containsAll(s)) {
				occ++;
			}
		}
		return occ;
	}

	public int numWordsFound(final Collection<String> arg) {
		int numInCollection = 0;
		for (final String st : arg) {
			final Integer i = getWordCount(st);
			if (i != null && i > 0) {
				numInCollection++;
			}
		}
		return numInCollection;
	}

	public int numWordsFound_simpleSingular(final Collection<String> arg) {
		int numInCollection = 0;
		for (final String st : arg) {
			Integer i = getWordCount(st);
			if (i == null) {
				i = 0;
			}
			if (!st.endsWith("es") && st.endsWith("s")) {
				final String singularForm = st.substring(0, st.length());
				Integer i2 = getWordCount(singularForm);
				if (i2 == null) {
					i2 = 0;
				}
				i = Math.max(i, i2);
			}
			if (i != null && i > 0) {
				numInCollection++;
			}
		}
		return numInCollection;
	}

	// get [Docids|Wordset[s]|Content[s]]

	/*
	 * (non-Javadoc)
	 * 
	 * @see util.D#getWordsetsWith(java.util.Collection)
	 */
	public Collection<Collection<String>> getWordsetsWith(final Collection<String> wordSet) {
		final Collection<Collection<String>> result = new HashSet<Collection<String>>();
		final Collection<Integer> gdh = getDocidsHavingSET(wordSet);
		for (final Integer i : gdh) {
			result.add(getWordset(i));
		}
		return result;
	}

	public static int hits = 0;
	public static int looks = 0;

	/*
	 * (non-Javadoc)
	 * 
	 * @see util.D#getDocidsWithAny(java.util.Collection)
	 */
	public Set<Integer> getDocidsWithAny(final Collection<String> wordSet) {
		final Set<Integer> result = new HashSet<Integer>();
		try {
			for (final String word : wordSet) {
				final List<Integer> docids = getDocidsWithWord(word);
				if (docids != null) {
					result.addAll(docids);
				}
			}
		} catch (final Exception e) {
			e.printStackTrace();
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see util.D#getWordsetsWithAny(java.util.Collection)
	 */
	public Collection<Collection<String>> getWordsetsWithAny(final Collection<String> wordSet) {
		final Set<Integer> docIDs = getDocidsWithAny(wordSet);
		final Collection<Collection<String>> result = new HashSet<Collection<String>>();
		result.addAll(getWordsets(docIDs));
		return result;
	}

	public Set<Integer> getDocidsHavingSLOW(final Collection<String> wordSet) {
		final Set<Integer> result = new HashSet<Integer>();
		for (final Doc doc : contents.docList) {
			if (doc.getWordset().containsAll(wordSet)) {
				result.add(doc.docID);
			}
		}
		return result;
	}

	public Collection<Integer> getDocidsHavingAll(final Collection<String> wordSet) {
		if (wordSet instanceof HashSet) {
			return getDocidsHavingSET(wordSet);
		}
		final Set<String> hs = new HashSet<String>();
		hs.addAll(wordSet);
		return getDocidsHavingSET(wordSet);
	}

	public Collection<Integer> getDocidsHaving(final Collection<String> wordSet, Boolean asSequence) {
		if (!asSequence) {
			return getDocidsHavingSET(new HashSet<String>(wordSet));
		}
		if (wordSet instanceof List || wordSet instanceof LinkedHashSet) {
			return getDocidsHavingSEQ(wordSet);
		}
		System.out.println("Cannot request sequence result for non-list input.");
		return null;
	}

	public Collection<Integer> keepDocsWithSet(final Collection<Integer> docsWithArgSET, final Collection<String> words) {
		final Collection<Integer> res = new ArrayList<Integer>();
		for (final int i : docsWithArgSET) {
			if (hasAllWords(i, words)) {
				res.add(i);
			}
		}
		return res;
	}

	public Collection<Integer> keepDocsWithSeq(final Collection<Integer> docsWithArgSEQ, final Collection<String> words) {
		final Collection<Integer> res = new ArrayList<Integer>();
		final Iterator<Integer> it = docsWithArgSEQ.iterator();
		int i;
		while (it.hasNext()) {
			if (hasWordsInorder(i = it.next(), words)) {
				res.add(i);
			}
		}
		return res;
	}

	public Collection<Integer> keepDocsWithPhr(final List<Integer> docsWithPHR, final Collection<String> words) {
		// final Collection<Integer> res = new ArrayList<Integer>();
		final ListIterator<Integer> it = docsWithPHR.listIterator();
		while (it.hasNext()) {
			if (!hasPhrase((it.next()), words)) {
				it.remove();
			}
		}
		return docsWithPHR;
	}

	public List<Integer> getDocidsHavingPHRASE(final Collection<String> words) {
		final List<Integer> res = new LinkedList<Integer>();
		final List<String> wordSeq = (List<String>) wordsByRarity(words);
		if (wordSeq == null || wordSeq.size() == 0) {
			return res;
		}
		final String anchorWord = wordSeq.get(0);
		final List<Integer> candidates = getDocidsWithWord(anchorWord);

		for (final int docId : candidates) {
			final List<String> content = getContent(docId);
			if (hasPhrase(content, words)) {
				res.add(docId);
			}
		}
		return res;
	}

	public boolean hasAllWords(final int docId, final Collection<String> words) {
		final Set<String> content = getWordset(docId);
		for (final String word : words) {
			if (!content.contains(word)) {
				return false;
			}
		}
		return true;
	}

	public boolean hasWordsInorder(final int docId, final Collection<String> words) {
		List<String> content = getContent(docId);
		int p;
		for (final String word : words) {
			if ((p = content.indexOf(word)) < 0) {
				return false;
			}
			content = content.subList(p + 1, content.size());
		}
		return true;
	}

	public boolean hasPhrase(final int docId, final Collection<String> winput) {
		return hasPhrase(getContent(docId), winput);
	}

	public boolean hasPhrase(final List<String> inContent, final Collection<String> winput) {
		List<String> content = inContent;
		if (winput == null || winput.size() == 0) {
			return true;
		}
		do {
			final Iterator<String> it = winput.iterator();
			final String headWord = it.next();
			final int headPos = content.indexOf(headWord);
			if (headPos < 0) {
				return false;
			}
			int pos = headPos + 1;
			boolean foundPhrase = true;
			while (pos < content.size() && it.hasNext()) {
				if (!content.get(pos++).equals(it.next())) {
					foundPhrase = false;
					break;
				}
			}
			if (foundPhrase && !it.hasNext()) {
				return true;
			}
			if (content.size() <= headPos + 1) {
				return false;
			}
			content = content.subList(headPos + 1, content.size());
		} while (true);
	}

	public Collection<String> wordsByRarity(final Collection<String> words) {
		final RankMap wordRankMap = contents.index.wordRanking.getRankmap();
		final SortedMap<Integer, String> itemsByRank = new TreeMap<Integer, String>();
		for (final String wordKey : words) {
			final Integer i = wordRankMap.get(wordKey.toLowerCase());
			if (i == null) {
				return new ArrayList<String>();
			}
			itemsByRank.put(i, wordKey);
		}
		return new ArrayList<String>(itemsByRank.values());
	}

	public Collection<Integer> getDocidsHavingSET(final Collection<String> words) {
		final Set<String> wordSet = (Set<String>) ((words instanceof Set)
				? words
				: new HashSet<String>(words));
		looks++;
		if (wordSet == null || wordSet.size() == 0) {
			return new HashSet<Integer>();
		}
		if (wordSet.size() == 1) {
			final String[] s = wordSet.toArray(new String[1]);
			final Collection<Integer> l = getDocidsWithWord(s[0]);
			return l;
		}
		if (instanceCache.containsKey(wordSet)) {
			hits++;
			return instanceCache.get(wordSet);
		}

		final Collection<String> wordSeq = wordsByRarity(words);
		final Iterator<String> wordIterator = wordSeq.iterator();
		if (!wordIterator.hasNext()) {
			return new ArrayList<Integer>();
		}
		String word = wordIterator.next();
		final List<Integer> hasAllExaminedWords = getDocidsWithWord(word);

		while (hasAllExaminedWords.size() > 0 && wordIterator.hasNext()) {
			word = wordIterator.next();
			final Set<Integer> nextWordSet = new HashSet<Integer>(getDocidsWithWord(word));
			final ListIterator<Integer> li = hasAllExaminedWords.listIterator();
			while (li.hasNext()) {
				if (!nextWordSet.contains(li.next())) {
					li.remove();
				}
			}
		}
		instanceCache.put(wordSet, hasAllExaminedWords);
		return hasAllExaminedWords;
	}

	/**
	 * Obtain document IDs for documents with the words occurring in sequence but not necessarily consecutively (i.e.,
	 * pos(Wi)<pos(Wi+1)). Does set retrieval and then spans the documents retrieved to discard ones that don't
	 * satisfy.
	 * 
	 * @param wordSequence
	 * @return intersectable list of document ids (i.e., sorted array)
	 */
	public List<Integer> getDocidsHavingSEQ(final Collection<String> wordSequence) {
		final List<Integer> res = new ArrayList<Integer>();
		if (wordSequence == null || wordSequence.size() < 1) {
			looks++;
			return res;
		}

		if (wordSequence.size() == 1) {
			looks++;
			final Iterator<String> it = wordSequence.iterator();
			final String word = it.next();
			return getDocidsWithWord(word);
		}

		final Collection<Integer> ansAsSets = getDocidsHavingSET(wordSequence);

		forEachDoc: for (final Integer docId : ansAsSets) {
			List<String> content = getContent(docId);
			if (true || debug) {
				System.out.print(">> Look for " + wordSequence.toString() + " in " + content.toString());
			}
			for (final String word : wordSequence) {
				final int pos = content.indexOf(word);
				if (pos < 0) {
					if (debug) {
						System.out.println(" [fail]");
					}
					continue forEachDoc;
				}
				content = content.subList(pos + 1, content.size());
			}
			if (debug) {
				System.out.println(" [found in " + docId + "]");
			}
			res.add(docId);
		}
		return res;
	}

	public Set<Set<String>> getWordsetsHaving(final Set<String> wordSet) {
		final Collection<Integer> docsHaving = getDocidsHavingSET(wordSet);
		final Set<Set<String>> result = new HashSet<Set<String>>();
		for (final Integer item : docsHaving) {
			result.add(getWordset(item));
		}
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see util.D#getContentsHaving(java.util.HashSet)
	 */
	public ArrayList<List<String>> getContentsHaving(final Set<String> wordSet) {
		final Collection<Integer> docsHaving = getDocidsHavingSET(wordSet);
		final ArrayList<List<String>> result = new ArrayList<List<String>>();
		for (final Integer item : docsHaving) {
			result.add(getContent(item));
		}
		result.trimToSize();
		return result;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see util.D#getWordset(java.lang.Integer)
	 */
	public Set<String> getWordset(final Integer docID) {
		return contents.docList.get(docID).getWordset();
	}

	public Set<Set<String>> getWordsets(final Collection<Integer> docidList) {
		final Set<Set<String>> result = new HashSet<Set<String>>();
		for (final Integer docID : docidList) {
			final Set<String> docWords = contents.docList.get(docID).getWordset();
			result.add(docWords);
		}
		return result;
	}

	public Set<String> getWordset(final int docId) {
		final Doc doc = contents.docList.get(docId);
		final Set<String> wordSet = doc.getWordset();
		return wordSet;
	}

	public ArrayList<String> getContent(final Integer docID) {
		return contents.docList.get(docID).getWordlist();
	}

	// BEGIN: COOCCURRENCES
	public Set<String> getCoOccuringContent(final String word) {
		final Set<String> wordsThatCooccur = new HashSet<String>();
		final List<Integer> docIdsWithWord = getDocidsWithWord(word);
		if (docIdsWithWord != null) {
			for (final Integer docNumber : docIdsWithWord) {
				wordsThatCooccur.addAll(getContent(docNumber));
			}
		}
		return wordsThatCooccur;
	}

	public Map<String, Set<String>> getCoOccurringContent(final Integer docID) {
		final ArrayList<String> wl = getContent(docID);
		final Map<String, Set<String>> cooccurrences = new HashMap<String, Set<String>>();
		for (final String s : wl) {
			cooccurrences.put(s, getCoOccuringContent(s));
		}
		return cooccurrences;
	}

	public Map<String, Set<String>> getCoOccurringContent(final Collection<String> wl) {
		final Map<String, Set<String>> cooccurrences = new HashMap<String, Set<String>>();
		for (final String s : wl) {
			cooccurrences.put(s, getCoOccuringContent(s));
		}
		return cooccurrences;
	}

	public Set<String> getCoOccurringWords(final Collection<String> wl) {
		final Set<String> result = new HashSet<String>();
		for (final Set<String> ss : getCoOccurringContent(wl).values()) {
			result.addAll(ss);
		}
		return result;
	}

	// END: COOCCURRENCS

	public List<List<String>> getContents(final Collection<Integer> docidList) {
		final ArrayList<List<String>> result = new ArrayList<List<String>>();
		for (final Integer docID : docidList) {
			final List<String> docWords = contents.docList.get(docID).getWordlist();
			result.add(docWords);
		}
		result.trimToSize();
		return result;
	}

	public Integer getWordFrequency(final String word) {
		final Collection<Integer> als = contents.index.lIndex.get(word);// .toLowerCase(Locale.getDefault()));
		return als == null
				? 0
				: als.size();
	}

	public List<Integer> getDocidsWithWord(final String word) {
		final Collection<Integer> ans = contents.index.lIndex.get(word);// .toLowerCase(Locale.getDefault()));
		return ans == null
				? new ArrayList<Integer>()
				: new ArrayList<Integer>(ans);
	}

	public List<ArrayList<String>> getContentsWithWord(final String word) {
		final List<Integer> doclist = getDocidsWithWord(word);
		final ArrayList<ArrayList<String>> result = new ArrayList<ArrayList<String>>();
		for (final Integer i : doclist) {
			result.add(getContent(i));
		}
		result.trimToSize();
		return result;
	}

	public Set<Set<String>> getWordsetsWithWord(final String word) {
		final List<Integer> doclist = getDocidsWithWord(word);
		final Set<Set<String>> result = new HashSet<Set<String>>();
		for (final Integer i : doclist) {
			result.add(getWordset(i));
		}
		return result;
	}

	public Integer getWordrank(final String word) {
		return contents.index.wordRanking.getRankmap().get(word.toLowerCase(Locale.getDefault()));
	}

	public Set<String> getWordsWithCount(final Integer count) {
		return contents.index.wordRanking.getFreqmap().get(count);
	}

	public String getRankword(final Integer i) {
		return contents.index.wordRanking.getRanklist().get(i);
	}

	public RankMap getRankmap() {
		return contents.index.wordRanking.getRankmap();
	}

	public FreqMap getFreqmap() {
		return contents.index.wordRanking.getFreqmap();
	}

	public Integer getWordfreq(final String word) {
		return contents.index.wordRanking.getWordFrequencies().get(word);
	}

	public Tally<String> getWordFrequencies() {
		return contents.index.wordRanking.getWordFrequencies();
	}

	public List<String> getRanklist() {
		return contents.index.wordRanking.getRanklist();
	}

	public Map<String, Integer> getIndocCount() {
		return stats.wordIndocCount.get();
	}

	public Integer getWordIndocCount(final String s) {
		return stats.wordIndocCount.get(s);
	}

	public Boolean expensiveTallies = false;

	public Map<Collection<String>, Integer> getWordsAsListCount() {
		return stats.wordsAsListCount.get();
	}

	public Map<Set<String>, Integer> getWordsAsSetCount() {
		return stats.wordsAsSetCount.get();
	}

	/**
	 * Show ranked word frequencies, count, item count and items.
	 * 
	 * @param out
	 *            Destination of output
	 */
	void showRankAndFreq(final PrintStream... streams) {
		final PrintStream[] out = streams.length == 0
				? new PrintStream[] { System.out }
				: streams;
		final FreqMap freqMap = getFreqmap(); // Integer-->String
		// RankMap rankMap = getRankmap();
		final Tally<String> wordFrequencies = getWordFrequencies();
		final List<Integer> ilist = new ArrayList<Integer>(freqMap.keySet());
		Collections.reverse(ilist);
		for (final Integer i : ilist) {
			final Set<String> words = freqMap.get(i);
			final String aWord = (new Object() {
				String pick(Set<String> s) {
					Iterator<String> it = s.iterator();
					return it.next();
				}
			}).pick(words);
			final Integer wFreq = wordFrequencies.get(aWord);
			out[0].printf("wordFreq=%-4d wordRank=%-3d numInstances=%-4d cummInstances=%-6d text=%s\n", wFreq, i, words.size(),
					words.size() * wFreq, words);
		}
	}

	public void doCorpusCompare(final String auxfile) {

		DocumentStore otherStats;
		System.out.println("other stats for " + auxfile);
		otherStats = new DocumentStore(auxfile);

		if (otherStats.getWordCount().size() == 0l) {
			return;
		}
		System.out.println("<<<<<<<< begin aux corpus comparison >>>>>>>>");
		System.out.println("base contains " + getWordCount().size());
		System.out.println("comp contains " + otherStats.getWordCount().size());
		// showCountStats(this.docStats);
		// showCountStats(otherStats);
		final DocumentStore.FreqMap f1 = getFreqmap();
		final DocumentStore.FreqMap f2 = otherStats.getFreqmap();
		final Set<String> f1Singletons = f1.get(Integer.valueOf(1));
		final Set<String> f2Singletons = f2.get(Integer.valueOf(1));
		f1Singletons.removeAll(f2Singletons);
		final Map<Integer, Set<String>> otherOcc = new TreeMap<Integer, Set<String>>();
		for (final String s : f1Singletons) {
			final Integer wocc = otherStats.getWordCount(s);
			if (wocc != null) {
				Set<String> strset = otherOcc.get(otherStats.getWordCount(s));
				if (strset == null) {
					strset = new HashSet<String>();
					otherOcc.put(otherStats.getWordCount(s), strset);
				}
				strset.add(s);
			}
		}
		for (final Integer i : otherOcc.keySet()) {
			final Set<String> strset = otherOcc.get(i);
			StringBuffer sb = new StringBuffer(String.format("Occurs once in file1, %d times in file2 [%d items]: ", i, strset
					.size()));
			final Iterator<String> it = strset.iterator();
			while (it.hasNext()) {
				if (sb.length() > outputColumns) {
					System.out.println(sb.toString());
					sb = new StringBuffer("  ");
				}
				final String word = it.next();
				sb.append(word);
				if (it.hasNext()) {
					sb.append(", ");
				}
			}
			System.out.println();
		}
	}

	// public class SimpleFischerKernel {
	// // Notation "n" follows [Hofmann2000](in [Muller], pp914-920)
	// // (a) Simplifying assumption is z[k]==w[k], so P(w[j]|z[k])
	// // is the word cooccurrence probability, and the inner
	// // sum also gets simplified because it looks at most into
	// // the words that occur in the document.
	// // (b) word occurrence in doc is zero/one

	// public Double l(int docID) {
	// Map<String,Set<String>>coOccuringContent = getCoOccurringContent(docID);
	// Double outerSum = 0D;
	// for(String s : getContent(docID)) {
	// Double hatValue = pHat(s,docID);
	// Double innerP = 0D;
	// for(String sInner : getContent(docID)) {
	// innerP += 1D/(1D*coOccuringContent.get(sInner).size());
	// outerSum += hatValue * Math.log(innerP);
	// }
	// }
	// return outerSum;
	// }
	// //cogitatated forth
	// public int n(Collection<String>words,String s) {
	// int cnt=0;
	// for(String st : words)cnt+=(st.equalsIgnoreCase(s))?1:0;
	// return cnt;
	// }
	// public int n(Integer docID, String s) {
	// int cnt=0;
	// for(String st : getContent(docID))cnt+=(st.equalsIgnoreCase(s))?1:0;
	// return cnt;
	// }
	// public int n(Integer docID, Integer wordID) {
	// return n(docID,docFactory.wordID.id(wordID));
	// }

	// public Double pHat(String word, Integer docID) {
	// int n = n(docID,word);
	// return (1D*n)/(1D*getContent(docID).size());
	// }
	// public Double pHat(Integer wordID, Integer docID) {
	// return pHat(docFactory.wordID.id(wordID), docID);
	// }

	// public Double pHat(Integer wordID, Collection<String>words) {
	// return pHat(docFactory.wordID.id(wordID),words);
	// }
	// //cogitated forth
	// public Double pHat(String word, Collection<String>words) {
	// int n =n(words,word);
	// return (1D*n)/(1D*words.size());
	// }
	// }

	public class Stat {
		Integer corpusWordcount;
		Double wordsEntropy;
		Integer corpusDoccount;
		Tally<String> wordCount;
		Tally<String> wordIndocCount;
		TallyCList<String> wordsAsListCount;
		TallyCSet<String> wordsAsSetCount;
		TreeMap<String, Double> tfidf;

		Stat() {
			corpusWordcount = 0;
			corpusDoccount = 0;
			wordsEntropy = null;
			wordCount = new Tally<String>();
			if (expensiveTallies) {
				wordIndocCount = new Tally<String>();
				wordsAsListCount = new TallyCList<String>();
				wordsAsSetCount = new TallyCSet<String>();
				tfidf = new TreeMap<String, Double>();
			}
		}

		void add(final Doc doc) {
			wordsEntropy = null;
			final StatOneitem oneDocTally = new StatOneitem(doc);
			corpusDoccount++;
			corpusWordcount += doc.wb.size();
			wordCount.add(oneDocTally.wordCount1);
			if (expensiveTallies) {
				wordsAsListCount.add(oneDocTally.wordsAsListCount1);
				wordsAsSetCount.add(oneDocTally.wordsAsSetCount1);
				wordIndocCount.add(oneDocTally.wordIndocCount1);
			}
		}

		Integer getCorpusDoccount() {
			return corpusDoccount;
		}

		Integer getCorpusWordcount() {
			return corpusWordcount;
		}

		void add(final Collection<Doc> docs) {
			for (final Doc doc : docs) {
				add(doc);
			}
		}

		Double computeEntropy() {
			final float[] probVector = wordCount.getFrequencies();
			final Double entropy = Numerics.entropy(probVector);
			return entropy;
		}

		Double getEntropy() {
			if (wordsEntropy == null) {
				wordsEntropy = computeEntropy();
			}
			return wordsEntropy;
		}

		Double getGroupEntropy(final Collection<String> words) {
			final ArrayList<Double> partialFrequencies = new ArrayList<Double>(words.size());
			for (final String word : words) {
				partialFrequencies.add(wordCount.getFrequency(word));
			}
			return Numerics.entropy(partialFrequencies);
		}

		Double getDocEntropy(final Collection<String> subset) {
			if (subset == null || subset.size() == 0) {
				return 0D;
			}
			final Collection<Integer> docidsHaving = getDocidsHavingSET(subset);
			if (docidsHaving == null) {
				return null;
			}
			Double pOfSubset = docidsHaving.size() / (1D * getCorpusWordcount());
			final Double entropy = -pOfSubset / Math.log(pOfSubset);
			return entropy;
		}

		Double getEntropy(final Collection<String> subset) {
			if (subset == null || subset.size() == 0) {
				return 0D;
			}
			Double sumEntropy = 0D;
			for (final String word : subset) {
				sumEntropy += getEntropy(word);
			}
			return sumEntropy / subset.size();
		}

		Double getEntropy(final String word) {
			final List<Integer> dlist = getDocidsWithWord(word);
			if (dlist == null) {
				return 0D;
			}
			Double p = dlist.size() * invNumwords;
			return -p / Math.log(p);
		}

		class StatOneitem {
			final Tally<String> wordCount1;
			TallyCList<String> wordsAsListCount1;
			TallyCSet<String> wordsAsSetCount1;
			Tally<String> wordIndocCount1;

			StatOneitem(final Doc doc) {
				wordCount1 = new Tally<String>();
				for (final String s : doc.getWordlist()) {
					wordCount1.inc(s);
				}
				if (expensiveTallies) {
					wordIndocCount1 = new Tally<String>();
					wordsAsListCount1 = new TallyCList<String>();
					wordsAsSetCount1 = new TallyCSet<String>();
					for (final String s : doc.getWordset()) {
						wordIndocCount1.inc(s);
					}
					wordsAsListCount1.insert(doc.getWordlist());
					wordsAsSetCount1.insert(doc.getWordlist());
				}
			}
		}

		// // Note: inverse document frequency is not typically helpful for
		// // lists of titles or company names, since this kind of text does
		// // not have many repeated words.
		TreeMap<String, Double> mkTfidf() {
			final TreeMap<String, Double> tfidfMap = new TreeMap<String, Double>();
			if (!expensiveTallies) {
				return tfidfMap;
			}
			final Map<String, Integer> termFreq = getWordCount();
			final Map<String, Integer> inDocFreq = getIndocCount();
			final Integer N = termFreq.size();
			final Double _N = N.doubleValue();
			for (final Map.Entry<String, Integer> tfreq : termFreq.entrySet()) {
				final String term = tfreq.getKey();
				final Integer tf = tfreq.getValue();
				final Integer df = inDocFreq.get(term);
				final Double idf = Math.log(_N / df.doubleValue());
				final Double tfidf1 = tf * idf;
				tfidfMap.put(term, tfidf1);
			}
			return tfidfMap;
		}

		List<Sortable> TFIDFlist() {
			if (!expensiveTallies) {
				return null;
			}
			final Map<String, Double> _tfidf = mkTfidf();
			final Map<String, Integer> _tf = getWordCount();
			final Map<String, Integer> _df = getIndocCount();
			final ArrayList<Sortable> TFIDFsort = new ArrayList<Sortable>();
			for (final Map.Entry<String, Double> tfidf1 : _tfidf.entrySet()) {
				final Double tfidfValue = tfidf1.getValue();
				final String term = tfidf1.getKey();
				final Integer tf = _tf.get(term);
				final Integer df = _df.get(term);
				TFIDFsort.add(new Sortable(tfidfValue, term, tf, df));
			}
			TFIDFsort.trimToSize();
			Collections.sort(TFIDFsort);
			return TFIDFsort;
		}
	}

	public class Content {
		ID id;
		public List<Doc> docList;
		public Map<List<String>, Doc> nameToDoc;
		public Index index;
		public int numItemWarnings;

		Content() {
			this(_siz);
		}

		Content(final int siz) {
			numItemWarnings = 0;
			id = new ID();
			docList = new ArrayList<Doc>(siz);
			nameToDoc = new HashMap<List<String>, Doc>();
			index = new Index();
		}

		void add(final Doc doc) {
			docList.add(doc);
			index.add(doc);
			// nameToSymbol.put(doc.getWordlist(), doc.getTickerOrRic());
			if (!nameToDoc.containsKey(doc.getWordlist())) {
				nameToDoc.put(doc.getWordlist(), doc);
			} else {
				numItemWarnings++;
				if (Constants.showItemWarnings) {
					System.out.print("WARNING: duplicate stopped item not added to reverse lookup list: " + doc);
				}
			}
		}

		void halfAdd(final Doc doc) {
			// index.add(doc);
			nameToDoc.put(doc.getWordlist(), doc);

		}

		public String findTickerForName(final List<String> name) {
			if (!nameToDoc.containsKey(name)) {
				System.err.println("ERROR: cannot get data for name on " + name.toString());
				return "dummyTicker";
			}
			return nameToDoc.get(name).getHandle();
		}

		public ArrayList<String> findOrigName(final List<String> name) {
			if (!nameToDoc.containsKey(name)) {
				System.err.println("ERROR: cannot get data for name on " + name.toString());
				return new ArrayList<String>(Arrays.asList("no content".split(" ")));
			}
			return nameToDoc.get(name).getWordlistOrig();
		}

		public String findRawContent(final List<String> name) {
			if (!nameToDoc.containsKey(name)) {
				System.err.println("ERROR: cannot get data for name on " + name.toString());
				return "no raw content.";
			}
			return nameToDoc.get(name).getRawContent();
		}

		class Index {
			public Map<String, Collection<Integer>> lIndex; // word --> (docID ...)
			RankMap rankMap;
			FreqMap freqMap;
			Tally<String> wordFrequencies;
			List<String> rankedOrder;
			WordRanking wordRanking;

			Integer getWordFreq(final String word) {
				final Collection<Integer> wordOcc = lIndex.get(word);
				return wordOcc == null
						? null
						: wordOcc.size();
			}

			class WordRanking {
				boolean valid;

				private class WFPair implements Comparable<WFPair>, Comparator<WFPair> {
					String word;
					Integer freq;

					WFPair() {
						word = null;
						freq = null;
						System.out.println("Made empty WFPair");
					}

					WFPair(final String word, final Integer freq) {
						this.word = word;
						this.freq = freq;
					}

					public int compareTo(final WFPair o) {
						final int cmp = freq - o.freq;
						if (cmp != 0) {
							return cmp;
						}
						return word.compareTo(o.word);
					}

					// Since we give a compareTo we should also follow best-practice and define an equals.
					public boolean equals(final WFPair o) {
						return this.compareTo(o) == 0;
					}

					@Override
					public boolean equals(final Object o) {
						if (!this.getClass().equals(o.getClass())) {
							return false;
						}
						return this.equals((WFPair) o);
					}

					// once we start with compareTo and equals, we should give hashCode too.
					@Override
					public int hashCode() {
						return super.hashCode() + word.hashCode() + freq.hashCode();
					}

					public int compare(final WFPair o1, final WFPair o2) {
						final int cmp = o1.freq - o2.freq;
						if (cmp != 0) {
							return cmp;
						}
						return o1.word.compareTo(o2.word);
					}
				}

				WordRanking() {
					wordRanking = this;
					rankMap = null;
					rankedOrder = null;
					wordFrequencies = null;
					valid = false;
				}

				RankMap getRankmap() {
					if (!valid) {
						mkWordRanking();
					}
					return rankMap;
				}

				FreqMap getFreqmap() {
					if (!valid) {
						mkWordRanking();
					}
					return freqMap;
				}

				Tally<String> getWordFrequencies() {
					if (!valid) {
						mkWordRanking();
					}
					return wordFrequencies;
				}

				List<String> getRanklist() {
					if (!valid) {
						mkWordRanking();
					}
					return rankedOrder;
				}

				// Builds both the rankMap and also the freqMap
				private void mkWordRanking() {
					wordFrequencies = new Tally<String>();
					for (int docID = 0; docID < getCorpusDoccount(); docID++) {
						final ArrayList<String> wl = getContent(docID);
						for (final String w : wl) {
							wordFrequencies.inc(w);
						}
					}
					final ArrayList<WFPair> winfo = new ArrayList<WFPair>(lIndex.size());
					for (final Map.Entry<String, Collection<Integer>> me : lIndex.entrySet()) {
						winfo.add(new WFPair(me.getKey(), me.getValue().size()));
					}
					Collections.sort(winfo);
					rankMap = new RankMap();
					rankedOrder = new ArrayList<String>();
					freqMap = new FreqMap();
					// Integer priorFrq = null;
					Integer rank = -1;
					Set<String> rNval = new HashSet<String>();
					for (Integer i = 0; i < winfo.size(); i++) {
						final String wrd = winfo.get(i).word;
						final Integer frq = winfo.get(i).freq;
						// TODO: problematic to have more than one word at the same rank, so what resolves ??
						// if (!frq.equals(priorFrq)) {
						rank++;
						// priorFrq = frq;
						rNval = new HashSet<String>();
						freqMap.put(rank, rNval);
						// }
						rankMap.put(wrd, rank);
						rankedOrder.add(wrd);
						rNval.add(wrd);
					}
					valid = true;
				}
			}

			Index() {
				lIndex = new HashMap<String, Collection<Integer>>();
				wordRanking = new WordRanking();
			}

			/**
			 * Add document to contentIndex, in order of increasing docID.
			 * 
			 * @param doc
			 *            to add
			 */
			@SuppressWarnings("unchecked")
			void add(final Doc doc) {
				for (final String wordKey : doc.getWordset()) {
					if (!lIndex.containsKey(wordKey)) {
						lIndex.put(wordKey, new ArrayList<Integer>());
					}
					lIndex.get(wordKey).add(doc.docID);
					wordRanking.valid = false;
				}
			}

			void showIndex() {
				for (final Map.Entry<String, Collection<Integer>> me : this.lIndex.entrySet()) {
					final String key = me.getKey();
					final Collection<Integer> als = me.getValue();
					System.out.println(key + " " + als);
				}
			}

			public Collection<Integer> docsWithWord(final String word) {
				return lIndex.get(word);
			}
		}

	}
}
